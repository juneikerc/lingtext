import{j as i,r as x,t as te,c as je}from"./translate-BlRPI3Pr.js";import{g as ne,n as re}from"./translation-GZuOJI6b.js";function Le(e){try{const t=JSON.parse(e);if(t&&typeof t=="object"&&t.word&&t.info)return t.info}catch{return null}return null}function Ce({popup:e,onSpeak:t,onSave:r,onClose:o}){const n=window.innerWidth||1200,s=window.innerHeight||800,g=Math.min(400,Math.max(280,n-24)),m=340,k=Math.min(Math.max(12,e.x-g/2),n-g-12),d=e.y>s/2;let p;d?p=Math.max(12,e.y-m-12):p=Math.min(Math.max(12,e.y+12),Math.max(12,s-m-12));const u=e.isLoading?null:Le(e.translation),v=e.text.length>100?`${e.text.substring(0,100)}...`:e.text;return i.jsxs("div",{"data-reader-popup":"true",className:"lingtext-reader-popup lingtext-selection-popup",style:{left:k,top:p,width:g},onClick:b=>b.stopPropagation(),children:[i.jsxs("div",{className:"lingtext-reader-popup-header",children:[i.jsxs("div",{className:"lingtext-reader-popup-title-group compact",children:[i.jsx("div",{className:"lingtext-reader-popup-icon small","aria-hidden":"true",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("span",{className:"lingtext-reader-selection-title",children:"Texto seleccionado"})]}),i.jsxs("div",{className:"lingtext-reader-popup-header-actions",children:[i.jsx("button",{className:"lingtext-reader-icon-button",onClick:()=>t(e.text),title:"Escuchar","aria-label":"Escuchar",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M15.54 8.46a5 5 0 0 1 0 7.07",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("button",{className:"lingtext-reader-icon-button",onClick:o,title:"Cerrar","aria-label":"Cerrar",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("path",{d:"M18 6 6 18M6 6l12 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})})})]})]}),i.jsx("div",{className:"lingtext-reader-section no-bottom-padding",children:i.jsx("div",{className:"lingtext-reader-card selected-text",children:i.jsxs("p",{children:["“",v,"”"]})})}),i.jsx("div",{className:"lingtext-reader-section",children:i.jsxs("div",{className:"lingtext-reader-card accent",children:[e.isLoading?i.jsxs("div",{className:"lingtext-reader-loading",role:"status",children:[i.jsx("span",{className:"lingtext-reader-loading-spinner"}),"Traduciendo..."]}):u?i.jsx("div",{className:"lingtext-reader-translation-list",children:Object.entries(u).map(([b,y])=>i.jsxs("div",{children:[i.jsx("p",{className:"lingtext-reader-category accent",children:b}),i.jsx("p",{className:"lingtext-reader-translation-text",children:y.join(", ")})]},b))}):i.jsx("span",{className:"lingtext-reader-selection-translation",children:e.translation}),e.disclaimer&&i.jsx("p",{className:"lingtext-reader-disclaimer",children:e.disclaimer})]})}),i.jsxs("div",{className:"lingtext-reader-actions with-border",children:[i.jsxs("button",{className:"lingtext-reader-action-button known",disabled:e.isLoading,onClick:()=>r(e.text,e.translation),children:[i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("polyline",{points:"20 6 9 17 4 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})}),"Guardar frase"]}),i.jsxs("button",{className:"lingtext-reader-action-button secondary",onClick:()=>t(e.text),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Escuchar"]})]})]})}const Se=/[A-Za-z]+(?:'[A-Za-z]+)?/g;function I(e){return e.toLowerCase().normalize("NFKD").replace(/[^a-z']+/g,"")}function G(e){const t=[];let r=0,o;for(;o=Se.exec(e);){const[n]=o,s=o.index,g=s+n.length;s>r&&t.push({text:e.slice(r,s),isWord:!1,start:r,end:s}),t.push({text:n,isWord:!0,start:s,end:g,lower:I(n)}),r=g}return r<e.length&&t.push({text:e.slice(r),isWord:!1,start:r,end:e.length}),t}function Me({text:e,unknownSet:t,phrases:r,onWordClick:o}){const n=G(e),s=x.useMemo(()=>{const d=new Map;for(const p of r){if(p.length<2)continue;const u=p[0],v=d.get(u);v?v.push(p):d.set(u,[p])}return d},[r]);if(!e)return null;const g=new Array(n.length).fill(!1),m=(d,p)=>{const u=[];let v=0,b=d;for(;b<n.length&&v<p.length;){if(!n[b].isWord){b++;continue}if((n[b].lower||I(n[b].text))!==p[v])return null;u.push(b),v++,b++}return v===p.length?u:null};for(let d=0;d<n.length;d++){if(!n[d].isWord)continue;const p=n[d].lower||I(n[d].text),u=s.get(p);if(u)for(const v of u){const b=m(d,v);if(b)for(const y of b)g[y]=!0}}const k=(d,p,u)=>{const v=d.currentTarget.getBoundingClientRect();o(p,u,v.left+v.width/2,v.top)};return i.jsx("div",{className:"lingtext-subtitle-overlay",children:n.map((d,p)=>{if(!d.isWord)return i.jsx("span",{children:d.text},p);const u=d.lower||I(d.text),v=t.has(u),b=g[p];return i.jsx("span",{className:`lingtext-word ${v?"lingtext-unknown":""} ${b?"lingtext-phrase":""}`,onClick:y=>k(y,d.text,u),children:d.text},p)})})}function Ee(e){try{const t=JSON.parse(e);if(t&&typeof t=="object"&&t.word&&t.info)return t.info}catch{return null}return null}function Ne({popup:e,isUnknown:t,onSpeak:r,onMarkKnown:o,onMarkUnknown:n,onClose:s}){const g=window.innerWidth||1200,m=window.innerHeight||800,k=Math.min(320,Math.max(260,g-24)),p=Math.max(12,m-320-12),u=Math.min(Math.max(12,e.x-k/2),g-k-12),v=Math.min(Math.max(12,e.y-80),p),b=e.isLoading?null:Ee(e.translation);return i.jsxs("div",{"data-reader-popup":"true",className:"lingtext-reader-popup lingtext-word-popup",style:{left:u,top:v,width:k},onClick:y=>y.stopPropagation(),children:[i.jsxs("div",{className:"lingtext-reader-popup-header",children:[i.jsxs("div",{className:"lingtext-reader-popup-title-group",children:[i.jsx("div",{className:"lingtext-reader-popup-icon","aria-hidden":"true",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M4 19.5A2.5 2.5 0 0 1 6.5 17H20",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsxs("div",{className:"lingtext-reader-popup-title",children:[i.jsx("h3",{children:e.word}),i.jsx("p",{children:"Palabra seleccionada"})]})]}),i.jsxs("div",{className:"lingtext-reader-popup-header-actions",children:[i.jsx("button",{className:"lingtext-reader-icon-button",onClick:()=>r(e.word),title:"Escuchar","aria-label":"Escuchar",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M15.54 8.46a5 5 0 0 1 0 7.07",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("button",{className:"lingtext-reader-icon-button",onClick:s,title:"Cerrar","aria-label":"Cerrar",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("path",{d:"M18 6 6 18M6 6l12 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})})})]})]}),i.jsx("div",{className:"lingtext-reader-section lingtext-reader-section-compact",children:i.jsxs("div",{className:"lingtext-reader-card",children:[e.isLoading?i.jsxs("div",{className:"lingtext-reader-loading",role:"status",children:[i.jsx("span",{className:"lingtext-reader-loading-spinner"}),"Traduciendo..."]}):b?i.jsx("div",{className:"lingtext-reader-translation-list",children:Object.entries(b).map(([y,A])=>i.jsxs("div",{children:[i.jsx("p",{className:"lingtext-reader-category",children:y}),i.jsx("p",{className:"lingtext-reader-translation-text",children:A.join(", ")})]},y))}):i.jsx("span",{className:"lingtext-reader-main-translation",children:e.translation}),e.disclaimer&&i.jsx("p",{className:"lingtext-reader-disclaimer",children:e.disclaimer})]})}),i.jsx("div",{className:"lingtext-reader-section lingtext-reader-status-section",children:i.jsxs("div",{className:`lingtext-reader-status-badge ${t?"unknown":"known"}`,children:[i.jsx("span",{}),t?"Por aprender":"Conocida"]})}),i.jsxs("div",{className:"lingtext-reader-actions",children:[t?i.jsxs("button",{className:"lingtext-reader-action-button known",onClick:()=>o(e.lower),children:[i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("polyline",{points:"20 6 9 17 4 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})}),"Marcar como conocida"]}):i.jsxs("button",{className:"lingtext-reader-action-button unknown",disabled:e.isLoading,onClick:()=>n(e.lower,e.word,e.translation),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M12 20h9",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Marcar para repasar"]}),i.jsxs("button",{className:"lingtext-reader-action-button secondary",onClick:()=>r(e.word),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Escuchar de nuevo"]})]})]})}function Te(e){const t=document.createElement("textarea");return t.innerHTML=e,t.value}function pe(e){return Te(e).replace(/\s+/g," ").trim()}function Ie(e){const t=JSON.parse(e);if(!Array.isArray(t.events))return[];const r=[];for(const o of t.events){if(!Array.isArray(o.segs)||typeof o.tStartMs!="number")continue;const n=pe(o.segs.map(k=>k.utf8||"").join(""));if(!n)continue;const s=o.tStartMs/1e3,g=typeof o.dDurationMs=="number"&&o.dDurationMs>0?o.dDurationMs:2e3,m=s+g/1e3;r.push({start:s,end:m,text:n})}return r}function Ae(e){const o=new DOMParser().parseFromString(e,"text/xml").querySelectorAll("text"),n=[];return o.forEach(s=>{const g=Number.parseFloat(s.getAttribute("start")||""),m=Number.parseFloat(s.getAttribute("dur")||"");if(!Number.isFinite(g))return;const k=pe(s.textContent||"");if(!k)return;const d=Number.isFinite(m)&&m>0?m:2;n.push({start:g,end:g+d,text:k})}),n}function ge(e){const t=e.trim();if(!t)return[];let r=[];if(t.startsWith("{"))try{r=Ie(t)}catch{r=[]}if(r.length===0)try{r=Ae(t)}catch{r=[]}return r.sort((o,n)=>o.start-n.start||o.end-n.end),r}function We(e){const t=(e.languageCode||"").toLowerCase(),r=(e.vssId||"").toLowerCase();return t.startsWith("en")||r.includes(".en")}function xe(e){const t=(e.vssId||"").toLowerCase();return e.kind==="asr"||t.startsWith("a.")}function oe(e){return e.replace(/\\u0026/g,"&")}function ie(e,t){try{const r=new URL(oe(e));return r.searchParams.set("fmt",t),r.toString()}catch{const r=oe(e);return r.includes("fmt=")?r.replace(/fmt=[^&]+/g,`fmt=${t}`):`${r}${r.includes("?")?"&":"?"}fmt=${t}`}}function Pe(e){return new Promise(t=>{const r=`${Date.now()}-${Math.random().toString(36).slice(2)}`,o=window.setTimeout(()=>{window.removeEventListener("message",n),t(null)},500);function n(s){if(s.source!==window||s.origin!==window.location.origin)return;const{type:g,requestId:m,payload:k}=s.data||{};if(g!=="LINGTEXT_YOUTUBE_CAPTION_TRACKS"||m!==r)return;window.clearTimeout(o),window.removeEventListener("message",n);const d=k;t(d.videoId&&d.videoId!==e?null:d)}window.addEventListener("message",n),window.postMessage({type:"LINGTEXT_GET_YOUTUBE_CAPTION_TRACKS",requestId:r},window.location.origin)})}function Re(e){const t=e.filter(We);return t.length===0?null:t.find(o=>!xe(o))||t[0]||null}async function _e(e){const t=[ie(e,"json3"),ie(e,"srv3")];for(const r of t)try{const o=await fetch(r);if(!o.ok)continue;const n=await o.text(),s=ge(n);if(s.length>0)return s}catch(o){console.warn("[LingText] Caption track fetch failed:",o)}return[]}async function Oe(e){const t=[{fmt:"json3",isAutoGenerated:!1},{fmt:"json3",isAutoGenerated:!0},{fmt:"srv3",isAutoGenerated:!1},{fmt:"srv3",isAutoGenerated:!0}];for(const r of t)try{const o=new URL("https://www.youtube.com/api/timedtext");o.searchParams.set("v",e),o.searchParams.set("lang","en"),o.searchParams.set("fmt",r.fmt),r.isAutoGenerated&&o.searchParams.set("kind","asr");const n=await fetch(o);if(!n.ok)continue;const s=await n.text(),g=ge(s);if(g.length>0)return{cues:g,isAutoGenerated:r.isAutoGenerated}}catch(o){console.warn("[LingText] Direct caption API failed:",o)}return null}async function Fe(e){const t=await Pe(e),r=Array.isArray(t==null?void 0:t.tracks)?t.tracks:[],o=Re(r);if(o!=null&&o.baseUrl){const s=await _e(o.baseUrl);if(s.length>0)return{cues:s,isAutoGenerated:xe(o)}}const n=await Oe(e);return n||null}function $(e){return e.replace(/\s+/g," ").trim()}function F(e){return G(e).filter(t=>t.isWord).map(t=>t.lower||I(t.text)).filter(Boolean)}function ze(e,t){if(t<=0)return e;const r=G(e);let o=0,n=!1,s="";for(const g of r){if(!n){g.isWord&&(o+=1,o>t&&(n=!0,s+=g.text));continue}s+=g.text}return s.trimStart()}function De(e,t){const r=Math.min(e.length,t.length);for(let o=r;o>=1;o-=1){let n=!0;for(let s=0;s<o;s+=1)if(e[e.length-o+s]!==t[s]){n=!1;break}if(n)return o}return 0}function Be(e,t){if(!t||t===e)return e;if(t.startsWith(e))return t;if(e.startsWith(t))return e;const r=F(e),o=F(t),n=De(r,o),s=ze(t,n);if(!s)return e;const g=/^[,.;:!?)]/.test(s)?"":" ";return`${e}${g}${s}`.replace(/\s+/g," ").trim()}function Ge(e,t){if(!e||!t)return!1;const r=$(e).toLowerCase(),o=$(t).toLowerCase();if(o.startsWith(r)&&o.length>r.length)return!0;const n=F(r),s=F(o);if(s.length<=n.length)return!1;let g=0;const m=Math.min(n.length,s.length);for(let k=0;k<m&&n[k]===s[k];k+=1)g+=1;return n.length<=2?g>=n.length:g>=n.length-1}function Ue(e){return/[.!?]["')\]]?$/.test(e.trim())}function qe(e){return F(e).length}function $e(e,t){if(e.length===0)return[];const r=[...e].map(p=>({start:Math.max(0,p.start),end:Math.max(p.end,p.start+.3),text:$(p.text)})).filter(p=>p.text.length>0).sort((p,u)=>p.start-u.start||p.end-u.end);if(r.length===0)return[];const o=[];let n={...r[0]};const s=t.isAutoGenerated?.65:.45,g=t.isAutoGenerated?6.5:6,m=84,k=18;for(let p=1;p<r.length;p+=1){const u=r[p];if(Ge(n.text,u.text)){n.text=u.text,n.end=Math.max(n.end,u.end);continue}const v=u.start-n.end,b=Be(n.text,u.text),y=Math.max(u.end,n.end)-n.start,A=v<=s&&y<=g&&b.length<=m&&qe(b)<=k,W=Ue(n.text);if(A&&(!W||t.isAutoGenerated)){n={start:n.start,end:Math.max(n.end,u.end),text:b};continue}o.push(n),n={...u}}o.push(n);const d=[];for(const p of o){const u=d[d.length-1];if(u&&u.text===p.text&&Math.abs(u.end-p.start)<.2){u.end=Math.max(u.end,p.end);continue}d.push(p)}return d}const ae="lingtext-native-caption-hide";function se(e){const t=document.getElementById(ae);if(!e){t==null||t.remove();return}if(t)return;const r=document.createElement("style");r.id=ae,r.textContent=`
    .ytp-caption-window-container {
      opacity: 0 !important;
      pointer-events: none !important;
    }
  `,document.head.appendChild(r)}function H(){return window.location.pathname!=="/watch"?null:new URLSearchParams(window.location.search).get("v")}function He(e){let t=H();e(t);const r=()=>{const n=H();n!==t&&(t=n,e(n))},o=window.setInterval(r,300);return window.addEventListener("popstate",r),window.addEventListener("yt-navigate-finish",r),()=>{window.clearInterval(o),window.removeEventListener("popstate",r),window.removeEventListener("yt-navigate-finish",r)}}function Ye(e){let t=null,r=null,o=null;const n=new MutationObserver(m),s=new MutationObserver(m);function g(){const d=document.querySelector("#movie_player");d!==r&&(n.disconnect(),r=d,d&&n.observe(d,{childList:!0,subtree:!0}))}function m(){g(),t===null&&(t=requestAnimationFrame(()=>{t=null;const d=document.querySelector("#movie_player");if(!d){o=null,e(null);return}const p=d.getBoundingClientRect(),u={left:p.left,top:p.top,width:p.width,height:p.height};o&&u.left===o.left&&u.top===o.top&&u.width===o.width&&u.height===o.height||(o=u,e(p))}))}const k=document.body||document.documentElement;return k&&s.observe(k,{childList:!0,subtree:!0}),window.addEventListener("resize",m),window.addEventListener("scroll",m,!0),m(),()=>{n.disconnect(),s.disconnect(),window.removeEventListener("resize",m),window.removeEventListener("scroll",m,!0),t!==null&&cancelAnimationFrame(t)}}function Ke(e,t){let r=0,o=e.length-1;for(;r<=o;){const n=r+o>>1,s=e[n];if(t<s.start){o=n-1;continue}if(t>=s.end){r=n+1;continue}return n}return-1}const Xe=80,q="lt2_youtube_subtitle_offset",le={x:0,y:0};function Ve(e){const t=e;return typeof(t==null?void 0:t.x)=="number"&&Number.isFinite(t.x)&&typeof t.y=="number"&&Number.isFinite(t.y)}function ce(e,t){if(!t)return e;const r=Math.max(0,t.width*.42),o=-Math.max(0,t.height-140);return{x:Math.min(Math.max(e.x,-r),r),y:Math.min(Math.max(e.y,o),36)}}function Je(){const e=document.querySelector(".ytp-subtitles-button");if(!e)return!1;const t=e.getAttribute("aria-pressed");return t==="true"?!0:t==="false"?!1:e.classList.contains("ytp-button-active")}function Ze({shadowRoot:e}){const t=x.useRef(null),r=x.useRef(null),o=x.useRef(0),n=x.useRef(0),s=x.useRef(le),g=x.useRef(null),[m,k]=x.useState(H()),[d,p]=x.useState(null),[u,v]=x.useState(ne),[b,y]=x.useState(new Set),[A,W]=x.useState([]),[z,P]=x.useState([]),[D,R]=x.useState(!1),[N,Y]=x.useState(!1),[L,M]=x.useState(""),[S,_]=x.useState(""),[fe,O]=x.useState(!1),[K,X]=x.useState(le),[U,C]=x.useState(null),[V,E]=x.useState(null);x.useEffect(()=>{const a=He(l=>{k(l),M(""),_(""),P([]),R(!1),o.current+=1,n.current+=1,C(null),E(null)}),c=Ye(l=>{p(l)});return()=>{a(),c()}},[]),x.useEffect(()=>{chrome.storage.local.get(q).then(a=>{const c=a[q];if(!Ve(c))return;const l=ce(c,d);s.current=l,X(l)}).catch(a=>{console.error("[LingText] Failed to load subtitle position:",a)})},[d]),x.useEffect(()=>{(async()=>{try{const[l,h,f]=await Promise.all([chrome.runtime.sendMessage({type:"LT2_GET_WORDS"}),chrome.runtime.sendMessage({type:"LT2_GET_PHRASES"}),chrome.runtime.sendMessage({type:"LT2_GET_SETTINGS"})]);y(new Set(l.map(w=>w.wordLower))),W(h.map(w=>w.parts)),v(re(f))}catch(l){console.error("[LingText] Failed to load extension data:",l)}})().catch(l=>{console.error("[LingText] Failed initial content load:",l)});const c=(l,h)=>{if(h==="local"){if(l.lt2_words){const f=l.lt2_words.newValue||[];y(new Set(f.map(w=>w.wordLower)))}if(l.lt2_phrases){const f=l.lt2_phrases.newValue||[];W(f.map(w=>w.parts))}if(l.lt2_settings){const f=l.lt2_settings.newValue||ne();v(re(f))}}};return chrome.storage.onChanged.addListener(c),()=>chrome.storage.onChanged.removeListener(c)},[]),x.useEffect(()=>{if(window.location.pathname!=="/watch"){Y(!1);return}let a=null;const c=()=>{a===null&&(a=requestAnimationFrame(()=>{a=null,Y(Je())}))},l=document.body||document.documentElement;if(!l){c();return}const h=new MutationObserver(c);h.observe(l,{attributes:!0,attributeFilter:["aria-pressed","class","style","hidden"],childList:!0,subtree:!0});const f=window.setInterval(c,500);return window.addEventListener("yt-navigate-finish",c),c(),()=>{h.disconnect(),window.clearInterval(f),window.removeEventListener("yt-navigate-finish",c),a!==null&&cancelAnimationFrame(a)}},[m]),x.useEffect(()=>{if(!m||window.location.pathname!=="/watch"){P([]),R(!1);return}let a=!1;return(async()=>{for(let l=0;l<3;l+=1){const h=await Fe(m);if(a)return;if(h&&h.cues.length>0){const f=$e(h.cues,{isAutoGenerated:h.isAutoGenerated});P(f),R(f.length>0);return}await new Promise(f=>setTimeout(f,900))}a||(P([]),R(!1))})().catch(l=>{console.error("[LingText] Failed to load transcript:",l),a||(P([]),R(!1))}),()=>{a=!0}},[m]),x.useEffect(()=>{if(!D||z.length===0||!N){M("");return}const a=document.querySelector("video");if(!a){M("");return}let c=0,l=-1;const h=()=>{const f=Ke(z,a.currentTime);f!==-1&&f!==l&&(l=f,M(z[f].text)),f===-1&&(l!==-1&&(l=-1),M("")),c=requestAnimationFrame(h)};return h(),()=>{cancelAnimationFrame(c)}},[N,D,z]),x.useEffect(()=>{if(D||window.location.pathname!=="/watch")return;let a=null,c="";const l=()=>{a===null&&(a=requestAnimationFrame(()=>{if(a=null,!N){c="",M("");return}const w=document.querySelectorAll(".ytp-caption-window-container .ytp-caption-segment"),j=Array.from(w).map(B=>B.textContent||"").join(" ").replace(/\s+/g," ").trim();j!==c&&(c=j,M(j))}))},h=document.body||document.documentElement;if(!h)return;const f=new MutationObserver(l);return f.observe(h,{childList:!0,subtree:!0,characterData:!0}),l(),()=>{f.disconnect(),a!==null&&cancelAnimationFrame(a)}},[N,D,m]),x.useEffect(()=>{if(L===S)return;if(!L){_(""),O(!1);return}if(!S){_(L),O(!1);return}const a=S.trim().toLowerCase(),c=L.trim().toLowerCase();if(a.length>0&&c.startsWith(a)){_(L),O(!1);return}return r.current&&clearTimeout(r.current),O(!0),r.current=setTimeout(()=>{_(L),O(!1)},Xe),()=>{r.current&&clearTimeout(r.current)}},[L,S]),x.useEffect(()=>{const a=u.hideNativeCc&&window.location.pathname==="/watch"&&N&&!!(L||S);return se(a),()=>{se(!1)}},[u.hideNativeCc,N,L,S]);const he=x.useCallback(async(a,c,l,h)=>{const f=o.current+1;o.current=f,n.current+=1,E(null),C({x:l,y:h,word:a,lower:c,translation:"",isLoading:!0});try{const w=await chrome.runtime.sendMessage({type:"LT2_GET_WORD",payload:c});if(f!==o.current)return;if(w){C({x:l,y:h,word:a,lower:c,translation:w.translation,disclaimer:void 0,isLoading:!1});return}const j=await te(a,u.translator,u.apiKey||void 0);if(f!==o.current)return;C({x:l,y:h,word:a,lower:c,translation:j.translation||"...",disclaimer:j.disclaimer,isLoading:!1})}catch(w){console.error("[LingText] Failed to open word popup:",w),f===o.current&&C({x:l,y:h,word:a,lower:c,translation:"No se pudo traducir.",isLoading:!1})}},[u]),J=x.useCallback(a=>{const c=new SpeechSynthesisUtterance(a);c.lang="en-US",speechSynthesis.speak(c)},[]),me=x.useCallback(async a=>{await chrome.runtime.sendMessage({type:"LT2_DELETE_WORD",payload:a}),y(c=>{const l=new Set(c);return l.delete(a),l}),C(null)},[]),be=x.useCallback(async(a,c,l)=>{const h={word:c,wordLower:a,translation:l,status:"unknown",addedAt:Date.now()};await chrome.runtime.sendMessage({type:"LT2_PUT_WORD",payload:h}),y(f=>{const w=new Set(f);return w.add(a),w}),C(null)},[]),Z=x.useCallback(()=>{o.current+=1,n.current+=1,C(null),E(null)},[]),Q=x.useCallback(a=>{chrome.storage.local.set({[q]:a}).catch(c=>{console.error("[LingText] Failed to save subtitle position:",c)})},[]),we=x.useCallback(a=>{a.preventDefault(),a.stopPropagation(),g.current={pointerId:a.pointerId,startX:a.clientX,startY:a.clientY,startOffset:s.current},a.currentTarget.setPointerCapture(a.pointerId)},[]),ke=x.useCallback(a=>{const c=g.current;if(!c||c.pointerId!==a.pointerId)return;a.preventDefault(),a.stopPropagation();const l=ce({x:c.startOffset.x+a.clientX-c.startX,y:c.startOffset.y+a.clientY-c.startY},d);s.current=l,X(l)},[d]),ee=x.useCallback(a=>{const c=g.current;!c||c.pointerId!==a.pointerId||(a.preventDefault(),a.stopPropagation(),g.current=null,a.currentTarget.hasPointerCapture(a.pointerId)&&a.currentTarget.releasePointerCapture(a.pointerId),Q(s.current))},[Q]),ve=x.useCallback(async()=>{var B;const a=((B=e.getSelection)==null?void 0:B.call(e))||document.getSelection();if(!a||a.isCollapsed)return;let c;try{c=a.getRangeAt(0)}catch{return}if(!t.current)return;const h=a.toString().trim();if(!h||h.length<3||h.split(/\s+/).map(T=>T.trim()).filter(Boolean).length<2)return;const w=c.getBoundingClientRect(),j=n.current+1;n.current=j,o.current+=1,E({x:w.left+w.width/2,y:w.top,text:h,translation:"",isLoading:!0}),C(null),a.removeAllRanges();try{const T=await te(h,u.translator,u.apiKey||void 0);if(j!==n.current)return;E({x:w.left+w.width/2,y:w.top,text:h,translation:T.translation||"...",disclaimer:T.disclaimer,isLoading:!1})}catch(T){console.error("[LingText] Failed to translate selection:",T),j===n.current&&E({x:w.left+w.width/2,y:w.top,text:h,translation:"No se pudo traducir.",isLoading:!1})}},[u.apiKey,u.translator,e]),ye=x.useCallback(async(a,c)=>{const l=G(a).filter(f=>f.isWord).map(f=>f.lower||I(f.text)).filter(Boolean);if(l.length<2)return;const h={phrase:a,phraseLower:l.join(" "),translation:c,parts:l,addedAt:Date.now()};await chrome.runtime.sendMessage({type:"LT2_PUT_PHRASE",payload:h}),W(f=>[...f,l]),E(null)},[]);return window.location.pathname!=="/watch"||!d||!S?null:i.jsxs("div",{ref:t,className:"lingtext-wrapper",style:{position:"fixed",left:d.left,top:d.top,width:d.width,height:d.height,pointerEvents:"none",zIndex:2147483646},onMouseUp:ve,children:[i.jsxs("div",{className:`lingtext-container ${fe?"lingtext-transitioning":""}`,style:{transform:`translate(calc(-50% + ${K.x}px), ${K.y}px)`},children:[i.jsx("button",{type:"button",className:"lingtext-drag-handle","aria-label":"Mover subtítulos",title:"Mover subtítulos",onPointerDown:we,onPointerMove:ke,onPointerUp:ee,onPointerCancel:ee,onClick:a=>a.stopPropagation(),onMouseUp:a=>a.stopPropagation(),children:i.jsx("span",{className:"lingtext-drag-handle-dots","aria-hidden":"true"})}),i.jsx(Me,{text:S,unknownSet:b,phrases:A,onWordClick:he})]}),U&&i.jsx(Ne,{popup:U,isUnknown:b.has(U.lower),onSpeak:J,onMarkKnown:me,onMarkUnknown:be,onClose:Z}),V&&i.jsx(Ce,{popup:V,onSpeak:J,onSave:ye,onClose:Z})]})}const de="lingtext-root",Qe=`
.lingtext-wrapper {
  pointer-events: none;
}

.lingtext-container {
  position: absolute;
  bottom: 56px;
  left: 50%;
  width: min(90%, 980px);
  text-align: center;
  pointer-events: auto;
  opacity: 1;
  transition: opacity 0.12s ease-in-out;
  user-select: text;
}

.lingtext-drag-handle {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 46px;
  height: 18px;
  margin: 0 auto 6px;
  padding: 0;
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 999px;
  background: rgba(10, 10, 10, 0.72);
  color: rgba(255, 255, 255, 0.78);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.28);
  cursor: grab;
  pointer-events: auto;
  touch-action: none;
}

.lingtext-drag-handle:active {
  cursor: grabbing;
}

.lingtext-drag-handle:focus-visible {
  outline: 2px solid rgba(15, 158, 218, 0.75);
  outline-offset: 2px;
}

.lingtext-drag-handle-dots {
  position: relative;
  display: block;
  width: 4px;
  height: 4px;
  border-radius: 999px;
  background: currentColor;
  box-shadow: -8px 0 currentColor, 8px 0 currentColor;
}

.lingtext-container.lingtext-transitioning {
  opacity: 0.78;
}

.lingtext-subtitle-overlay {
  display: inline;
  background: rgba(10, 10, 10, 0.86);
  color: #ffffff;
  padding: 10px 16px;
  border-radius: 6px;
  font-size: clamp(20px, 2.05vw, 30px);
  line-height: 1.35;
  font-family: "YouTube Noto", Roboto, Arial, sans-serif;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.75);
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}

.lingtext-word {
  cursor: pointer;
  border-radius: 2px;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.lingtext-word:hover {
  background: rgba(59, 130, 246, 0.42);
}

.lingtext-unknown {
  background: rgba(234, 179, 8, 0.26);
  border-bottom: 2px solid rgba(234, 179, 8, 0.7);
  font-weight: 600;
}

.lingtext-unknown:hover {
  background: rgba(234, 179, 8, 0.38);
}

.lingtext-phrase {
  text-decoration: underline;
  text-decoration-color: #4ade80;
  text-underline-offset: 4px;
}

.lingtext-reader-popup {
  --reader-surface-bg: rgba(255, 255, 255, 0.97);
  --reader-muted-bg: rgba(249, 250, 251, 0.97);
  --reader-text-color: #111827;
  --reader-muted-text-color: #6b7280;
  --reader-border-color: rgba(229, 231, 235, 0.95);
  --reader-accent-color: #0f9eda;
  position: fixed;
  z-index: 2147483647;
  background: var(--reader-surface-bg);
  color: var(--reader-text-color);
  border: 1px solid var(--reader-border-color);
  border-radius: 16px;
  box-shadow: 0 20px 42px rgba(15, 23, 42, 0.22);
  overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  font-size: 14px;
  pointer-events: auto;
  backdrop-filter: blur(12px);
}

.lingtext-reader-popup * {
  box-sizing: border-box;
}

.lingtext-reader-popup button {
  font-family: inherit;
}

.lingtext-reader-popup-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--reader-border-color);
  background: var(--reader-muted-bg);
}

.lingtext-reader-popup-title-group {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.lingtext-reader-popup-title-group.compact {
  gap: 10px;
}

.lingtext-reader-popup-icon {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: 12px;
  background: rgba(15, 158, 218, 0.12);
  color: var(--reader-accent-color);
}

.lingtext-reader-popup-icon.small {
  width: 32px;
  height: 32px;
}

.lingtext-reader-popup-icon svg,
.lingtext-reader-icon-button svg,
.lingtext-reader-action-button svg {
  width: 16px;
  height: 16px;
}

.lingtext-reader-popup-title {
  min-width: 0;
}

.lingtext-reader-popup-title h3 {
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.2;
}

.lingtext-reader-popup-title p {
  margin: 2px 0 0;
  color: var(--reader-muted-text-color);
  font-size: 11px;
  line-height: 1.2;
}

.lingtext-reader-selection-title {
  color: #1f2937;
  font-size: 14px;
  font-weight: 600;
}

.lingtext-reader-popup-header-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.lingtext-reader-icon-button {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: #6b7280;
  cursor: pointer;
  transition: background-color 0.2s ease, color 0.2s ease, opacity 0.2s ease;
}

.lingtext-reader-icon-button:hover {
  background: rgba(243, 244, 246, 0.9);
  color: #374151;
}

.lingtext-reader-icon-button:focus-visible,
.lingtext-reader-action-button:focus-visible {
  outline: 2px solid rgba(15, 158, 218, 0.55);
  outline-offset: 2px;
}

.lingtext-reader-section {
  padding: 12px 16px;
}

.lingtext-reader-section-compact {
  padding-bottom: 8px;
}

.lingtext-reader-section.no-bottom-padding {
  padding-bottom: 0;
}

.lingtext-reader-status-section {
  padding-top: 4px;
  padding-bottom: 8px;
}

.lingtext-reader-card {
  padding: 12px;
  border: 1px solid var(--reader-border-color);
  border-radius: 12px;
  background: var(--reader-muted-bg);
}

.lingtext-reader-card.accent {
  background: rgba(15, 158, 218, 0.05);
  border-color: rgba(15, 158, 218, 0.1);
}

.lingtext-reader-loading {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 28px;
  color: #6b7280;
  font-size: 13px;
  font-weight: 600;
}

.lingtext-reader-loading-spinner {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  border: 2px solid rgba(15, 158, 218, 0.18);
  border-top-color: #0f9eda;
  border-radius: 999px;
  animation: lingtext-reader-spin 0.75s linear infinite;
}

@keyframes lingtext-reader-spin {
  to {
    transform: rotate(360deg);
  }
}

@media (prefers-reduced-motion: reduce) {
  .lingtext-reader-loading-spinner {
    animation: none;
  }
}

.lingtext-reader-card.selected-text p {
  margin: 0;
  color: #374151;
  font-size: 14px;
  font-style: italic;
  line-height: 1.55;
}

.lingtext-reader-translation-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.lingtext-reader-category {
  margin: 0 0 2px;
  color: rgba(17, 24, 39, 0.5);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.04em;
  line-height: 1.2;
  text-transform: uppercase;
}

.lingtext-reader-category.accent {
  color: rgba(15, 158, 218, 0.7);
}

.lingtext-reader-translation-text {
  margin: 0;
  color: #1f2937;
  font-size: 14px;
  line-height: 1.4;
}

.lingtext-reader-disclaimer {
  margin: 6px 0 0;
  color: rgba(31, 41, 55, 0.55);
  font-size: 11px;
  line-height: 1.25;
}

.lingtext-reader-main-translation {
  display: inline-block;
  color: #111827;
  font-size: 18px;
  font-weight: 700;
  line-height: 1.35;
}

.lingtext-reader-selection-translation {
  display: inline-block;
  color: #111827;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.4;
}

.lingtext-reader-status-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  line-height: 1;
}

.lingtext-reader-status-badge span {
  width: 6px;
  height: 6px;
  border-radius: 999px;
}

.lingtext-reader-status-badge.unknown {
  background: #fff7ed;
  color: #c2410c;
  border: 1px solid #fed7aa;
}

.lingtext-reader-status-badge.unknown span {
  background: #f97316;
}

.lingtext-reader-status-badge.known {
  background: #f0fdf4;
  color: #15803d;
  border: 1px solid #bbf7d0;
}

.lingtext-reader-status-badge.known span {
  background: #22c55e;
}

.lingtext-reader-actions {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 4px 16px 16px;
}

.lingtext-reader-actions.with-border {
  padding-top: 12px;
  border-top: 1px solid var(--reader-border-color);
  background: var(--reader-surface-bg);
}

.lingtext-reader-action-button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  min-height: 42px;
  padding: 10px 16px;
  border: 1px solid transparent;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.2;
  cursor: pointer;
  transition: background-color 0.2s ease, box-shadow 0.2s ease, opacity 0.2s ease;
}

.lingtext-reader-action-button:hover {
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.1);
}

.lingtext-reader-action-button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
  box-shadow: none;
}

.lingtext-reader-action-button.known {
  background: #f0fdf4;
  color: #15803d;
  border-color: #bbf7d0;
}

.lingtext-reader-action-button.known:hover {
  background: #dcfce7;
}

.lingtext-reader-action-button.unknown {
  background: #fff7ed;
  color: #c2410c;
  border-color: #fed7aa;
}

.lingtext-reader-action-button.unknown:hover {
  background: #ffedd5;
}

.lingtext-reader-action-button.secondary {
  background: var(--reader-muted-bg);
  color: #4b5563;
  border-color: var(--reader-border-color);
}

.lingtext-reader-action-button.secondary:hover {
  background: #f9fafb;
}
`;function ue(){if(document.getElementById(de))return;const e=document.createElement("div");e.id=de,document.body.appendChild(e);const t=e.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=Qe,t.appendChild(r);const o=document.createElement("div");t.appendChild(o),je.createRoot(o).render(i.jsx(Ze,{shadowRoot:t}))}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",ue,{once:!0}):ue();
