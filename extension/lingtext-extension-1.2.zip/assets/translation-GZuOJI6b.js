var t=(e=>(e.CHROME="chrome",e.MYMEMORY="mymemory",e.MEDIUM="google/gemini-2.5-flash-lite",e.SMART="google/gemini-3.1-flash-lite-preview",e))(t||{});function a(){var n;const e=((n=globalThis.navigator)==null?void 0:n.userAgent)??"";return e.includes("Chrome")&&!e.includes("Edg")&&!e.includes("OPR")&&!e.includes("Firefox")}function i(){return{translator:a()?t.CHROME:t.MYMEMORY,apiKey:"",captionLanguage:"en",hideNativeCc:!0}}function o(e){const r={...i(),...e,captionLanguage:"en"};return!a()&&r.translator===t.CHROME&&(r.translator=t.MYMEMORY),r}const s={[t.CHROME]:"⚡ Rápido | Básico",[t.MYMEMORY]:"🆓 Gratis | Básico",[t.MEDIUM]:"🧠 Inteligente | Medio",[t.SMART]:"🚀 Muy Inteligente"};function u(e){return e.trim().replace(/[<>"'&]/g,"")}function l(e){return`You are a machine that outputs strict JSON. You receive an English word and output its Spanish translations grouped by grammatical category as a list of strings.
Rules:
1. Use only valid JSON.
2. Values must be arrays of strings.
3. Only include relevant categories.

some of the categories are: Noun, Verb, Adjective, Adverb, Pronoun, Preposition, Conjunction, Interjection, Phrase, Sentence,.

EXAMPLES:

User: "run"
Assistant:
{
  "word": "run",
  "info": {
    "Verb": ["correr", "ejecutar", "administrar"],
    "Noun": ["carrera", "recorrido", "racha"]
  }
}

User: "fast"
Assistant:
{
  "word": "fast",
  "info": {
    "Adjective": ["rápido", "veloz", "adelantado"],
    "Adverb": ["rápidamente"],
    "Noun": ["ayuno"],
    "Verb": ["ayunar"]
  }
}

User: "beautiful"
Assistant:
{
  "word": "beautiful",
  "info": {
    "Adjective": ["hermoso", "bello", "bonito"]
  }
}

If a verb is in the past tense, indicate this with (pasado)

translate this word to spanish: ${e} (respond only with the translation no additional text)`}function c(e){return e.replaceAll("```","").replace("json","").trim()}export{t as T,s as a,l as b,c,i as g,o as n,u as s};
