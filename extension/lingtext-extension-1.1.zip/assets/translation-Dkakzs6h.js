var t=(e=>(e.CHROME="chrome",e.MYMEMORY="mymemory",e.MEDIUM="google/gemini-2.5-flash-lite",e.SMART="google/gemini-3.1-flash-lite-preview",e))(t||{});const r={[t.CHROME]:"⚡ Rápido | Básico",[t.MYMEMORY]:"🆓 Gratis | Básico",[t.MEDIUM]:"🧠 Inteligente | Medio",[t.SMART]:"🚀 Muy Inteligente"};function n(e){return e.trim().replace(/[<>"'&]/g,"")}function a(e){return`You are a machine that outputs strict JSON. You receive an English word and output its Spanish translations grouped by grammatical category as a list of strings.
Rules:
1. Use only valid JSON.
2. Values must be arrays of strings.
3. Only include relevant categories.

some of the categories are: Noun, Verb, Adjective, Adverb, Pronoun, Preposition, Conjunction, Interjection, Phrase, Sentence,.

EXAMPLES:

User: "run"
Assistant:
{
  "word": "run",
  "info": {
    "Verb": ["correr", "ejecutar", "administrar"],
    "Noun": ["carrera", "recorrido", "racha"]
  }
}

User: "fast"
Assistant:
{
  "word": "fast",
  "info": {
    "Adjective": ["rápido", "veloz", "adelantado"],
    "Adverb": ["rápidamente"],
    "Noun": ["ayuno"],
    "Verb": ["ayunar"]
  }
}

User: "beautiful"
Assistant:
{
  "word": "beautiful",
  "info": {
    "Adjective": ["hermoso", "bello", "bonito"]
  }
}

If a verb is in the past tense, indicate this with (pasado)

translate this word to spanish: ${e} (respond only with the translation no additional text)`}function o(e){return e.replaceAll("```","").replace("json","").trim()}export{t as T,r as a,a as b,o as c,n as s};
