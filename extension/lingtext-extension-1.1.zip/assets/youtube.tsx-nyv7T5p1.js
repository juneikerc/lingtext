import{j as i,r as f,t as q,c as de}from"./translate-CVsMsjGM.js";import{T as ue}from"./translation-Dkakzs6h.js";function pe(e){try{const t=JSON.parse(e);if(t&&typeof t=="object"&&t.word&&t.info)return t.info}catch{return null}return null}function ge({popup:e,onSpeak:t,onSave:n,onClose:o}){const r=window.innerWidth||1200,a=window.innerHeight||800,g=Math.min(400,Math.max(280,r-24)),h=340,b=Math.min(Math.max(12,e.x-g/2),r-g-12),u=e.y>a/2;let s;u?s=Math.max(12,e.y-h-12):s=Math.min(Math.max(12,e.y+12),Math.max(12,a-h-12));const d=pe(e.translation),v=e.text.length>100?`${e.text.substring(0,100)}...`:e.text;return i.jsxs("div",{"data-reader-popup":"true",className:"lingtext-reader-popup lingtext-selection-popup",style:{left:b,top:s,width:g},onClick:w=>w.stopPropagation(),children:[i.jsxs("div",{className:"lingtext-reader-popup-header",children:[i.jsxs("div",{className:"lingtext-reader-popup-title-group compact",children:[i.jsx("div",{className:"lingtext-reader-popup-icon small","aria-hidden":"true",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("span",{className:"lingtext-reader-selection-title",children:"Texto seleccionado"})]}),i.jsxs("div",{className:"lingtext-reader-popup-header-actions",children:[i.jsx("button",{className:"lingtext-reader-icon-button",onClick:()=>t(e.text),title:"Escuchar","aria-label":"Escuchar",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M15.54 8.46a5 5 0 0 1 0 7.07",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("button",{className:"lingtext-reader-icon-button",onClick:o,title:"Cerrar","aria-label":"Cerrar",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("path",{d:"M18 6 6 18M6 6l12 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})})})]})]}),i.jsx("div",{className:"lingtext-reader-section no-bottom-padding",children:i.jsx("div",{className:"lingtext-reader-card selected-text",children:i.jsxs("p",{children:["“",v,"”"]})})}),i.jsx("div",{className:"lingtext-reader-section",children:i.jsx("div",{className:"lingtext-reader-card accent",children:d?i.jsx("div",{className:"lingtext-reader-translation-list",children:Object.entries(d).map(([w,k])=>i.jsxs("div",{children:[i.jsx("p",{className:"lingtext-reader-category accent",children:w}),i.jsx("p",{className:"lingtext-reader-translation-text",children:k.join(", ")})]},w))}):i.jsx("span",{className:"lingtext-reader-selection-translation",children:e.translation})})}),i.jsxs("div",{className:"lingtext-reader-actions with-border",children:[i.jsxs("button",{className:"lingtext-reader-action-button known",onClick:()=>n(e.text,e.translation),children:[i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("polyline",{points:"20 6 9 17 4 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})}),"Guardar frase"]}),i.jsxs("button",{className:"lingtext-reader-action-button secondary",onClick:()=>t(e.text),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Escuchar"]})]})]})}const xe=/[A-Za-z]+(?:'[A-Za-z]+)?/g;function A(e){return e.toLowerCase().normalize("NFKD").replace(/[^a-z']+/g,"")}function B(e){const t=[];let n=0,o;for(;o=xe.exec(e);){const[r]=o,a=o.index,g=a+r.length;a>n&&t.push({text:e.slice(n,a),isWord:!1,start:n,end:a}),t.push({text:r,isWord:!0,start:a,end:g,lower:A(r)}),n=g}return n<e.length&&t.push({text:e.slice(n),isWord:!1,start:n,end:e.length}),t}function he({text:e,unknownSet:t,phrases:n,onWordClick:o}){const r=B(e),a=f.useMemo(()=>{const u=new Map;for(const s of n){if(s.length<2)continue;const d=s[0],v=u.get(d);v?v.push(s):u.set(d,[s])}return u},[n]);if(!e)return null;const g=new Array(r.length).fill(!1),h=(u,s)=>{const d=[];let v=0,w=u;for(;w<r.length&&v<s.length;){if(!r[w].isWord){w++;continue}if((r[w].lower||A(r[w].text))!==s[v])return null;d.push(w),v++,w++}return v===s.length?d:null};for(let u=0;u<r.length;u++){if(!r[u].isWord)continue;const s=r[u].lower||A(r[u].text),d=a.get(s);if(d)for(const v of d){const w=h(u,v);if(w)for(const k of w)g[k]=!0}}const b=(u,s,d)=>{const v=u.currentTarget.getBoundingClientRect();o(s,d,v.left+v.width/2,v.top)};return i.jsx("div",{className:"lingtext-subtitle-overlay",children:r.map((u,s)=>{if(!u.isWord)return i.jsx("span",{children:u.text},s);const d=u.lower||A(u.text),v=t.has(d),w=g[s];return i.jsx("span",{className:`lingtext-word ${v?"lingtext-unknown":""} ${w?"lingtext-phrase":""}`,onClick:k=>b(k,u.text,d),children:u.text},s)})})}function fe(e){try{const t=JSON.parse(e);if(t&&typeof t=="object"&&t.word&&t.info)return t.info}catch{return null}return null}function me({popup:e,isUnknown:t,onSpeak:n,onMarkKnown:o,onMarkUnknown:r,onClose:a}){const g=window.innerWidth||1200,h=window.innerHeight||800,b=Math.min(320,Math.max(260,g-24)),s=Math.max(12,h-320-12),d=Math.min(Math.max(12,e.x-b/2),g-b-12),v=Math.min(Math.max(12,e.y-80),s),w=fe(e.translation);return i.jsxs("div",{"data-reader-popup":"true",className:"lingtext-reader-popup lingtext-word-popup",style:{left:d,top:v,width:b},onClick:k=>k.stopPropagation(),children:[i.jsxs("div",{className:"lingtext-reader-popup-header",children:[i.jsxs("div",{className:"lingtext-reader-popup-title-group",children:[i.jsx("div",{className:"lingtext-reader-popup-icon","aria-hidden":"true",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M4 19.5A2.5 2.5 0 0 1 6.5 17H20",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsxs("div",{className:"lingtext-reader-popup-title",children:[i.jsx("h3",{children:e.word}),i.jsx("p",{children:"Palabra seleccionada"})]})]}),i.jsxs("div",{className:"lingtext-reader-popup-header-actions",children:[i.jsx("button",{className:"lingtext-reader-icon-button",onClick:()=>n(e.word),title:"Escuchar","aria-label":"Escuchar",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M15.54 8.46a5 5 0 0 1 0 7.07",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("button",{className:"lingtext-reader-icon-button",onClick:a,title:"Cerrar","aria-label":"Cerrar",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("path",{d:"M18 6 6 18M6 6l12 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})})})]})]}),i.jsx("div",{className:"lingtext-reader-section lingtext-reader-section-compact",children:i.jsx("div",{className:"lingtext-reader-card",children:w?i.jsx("div",{className:"lingtext-reader-translation-list",children:Object.entries(w).map(([k,L])=>i.jsxs("div",{children:[i.jsx("p",{className:"lingtext-reader-category",children:k}),i.jsx("p",{className:"lingtext-reader-translation-text",children:L.join(", ")})]},k))}):i.jsx("span",{className:"lingtext-reader-main-translation",children:e.translation})})}),i.jsx("div",{className:"lingtext-reader-section lingtext-reader-status-section",children:i.jsxs("div",{className:`lingtext-reader-status-badge ${t?"unknown":"known"}`,children:[i.jsx("span",{}),t?"Por aprender":"Conocida"]})}),i.jsxs("div",{className:"lingtext-reader-actions",children:[t?i.jsxs("button",{className:"lingtext-reader-action-button known",onClick:()=>o(e.lower),children:[i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("polyline",{points:"20 6 9 17 4 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})}),"Marcar como conocida"]}):i.jsxs("button",{className:"lingtext-reader-action-button unknown",onClick:()=>r(e.lower,e.word,e.translation),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M12 20h9",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Marcar para repasar"]}),i.jsxs("button",{className:"lingtext-reader-action-button secondary",onClick:()=>n(e.word),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Escuchar de nuevo"]})]})]})}function we(e){const t=document.createElement("textarea");return t.innerHTML=e,t.value}function ee(e){return we(e).replace(/\s+/g," ").trim()}function be(e){const t=JSON.parse(e);if(!Array.isArray(t.events))return[];const n=[];for(const o of t.events){if(!Array.isArray(o.segs)||typeof o.tStartMs!="number")continue;const r=ee(o.segs.map(b=>b.utf8||"").join(""));if(!r)continue;const a=o.tStartMs/1e3,g=typeof o.dDurationMs=="number"&&o.dDurationMs>0?o.dDurationMs:2e3,h=a+g/1e3;n.push({start:a,end:h,text:r})}return n}function ve(e){const o=new DOMParser().parseFromString(e,"text/xml").querySelectorAll("text"),r=[];return o.forEach(a=>{const g=Number.parseFloat(a.getAttribute("start")||""),h=Number.parseFloat(a.getAttribute("dur")||"");if(!Number.isFinite(g))return;const b=ee(a.textContent||"");if(!b)return;const u=Number.isFinite(h)&&h>0?h:2;r.push({start:g,end:g+u,text:b})}),r}function te(e){const t=e.trim();if(!t)return[];let n=[];if(t.startsWith("{"))try{n=be(t)}catch{n=[]}if(n.length===0)try{n=ve(t)}catch{n=[]}return n.sort((o,r)=>o.start-r.start||o.end-r.end),n}function ke(e){const t=(e.languageCode||"").toLowerCase(),n=(e.vssId||"").toLowerCase();return t.startsWith("en")||n.includes(".en")}function ne(e){const t=(e.vssId||"").toLowerCase();return e.kind==="asr"||t.startsWith("a.")}function K(e){return e.replace(/\\u0026/g,"&")}function V(e,t){try{const n=new URL(K(e));return n.searchParams.set("fmt",t),n.toString()}catch{const n=K(e);return n.includes("fmt=")?n.replace(/fmt=[^&]+/g,`fmt=${t}`):`${n}${n.includes("?")?"&":"?"}fmt=${t}`}}function J(e){var o,r;const t=e,n=(r=(o=t==null?void 0:t.captions)==null?void 0:o.playerCaptionsTracklistRenderer)==null?void 0:r.captionTracks;return Array.isArray(n)?n:[]}function ye(){var n,o,r;const e=J(window.ytInitialPlayerResponse);if(e.length>0)return e;const t=(r=(o=(n=window.ytplayer)==null?void 0:n.config)==null?void 0:o.args)==null?void 0:r.player_response;if(typeof t=="string"&&t)try{return J(JSON.parse(t))}catch{return[]}return[]}function je(e){const t=e.filter(ke);return t.length===0?null:t.find(o=>!ne(o))||t[0]||null}async function Le(e){const t=[V(e,"json3"),V(e,"srv3")];for(const n of t)try{const o=await fetch(n);if(!o.ok)continue;const r=await o.text(),a=te(r);if(a.length>0)return a}catch(o){console.warn("[LingText] Caption track fetch failed:",o)}return[]}async function Ce(e){const t=[{fmt:"json3",isAutoGenerated:!1},{fmt:"json3",isAutoGenerated:!0},{fmt:"srv3",isAutoGenerated:!1},{fmt:"srv3",isAutoGenerated:!0}];for(const n of t)try{const o=new URL("https://www.youtube.com/api/timedtext");o.searchParams.set("v",e),o.searchParams.set("lang","en"),o.searchParams.set("fmt",n.fmt),n.isAutoGenerated&&o.searchParams.set("kind","asr");const r=await fetch(o);if(!r.ok)continue;const a=await r.text(),g=te(a);if(g.length>0)return{cues:g,isAutoGenerated:n.isAutoGenerated}}catch(o){console.warn("[LingText] Direct caption API failed:",o)}return null}async function Se(e){const t=ye(),n=je(t);if(n!=null&&n.baseUrl){const r=await Le(n.baseUrl);if(r.length>0)return{cues:r,isAutoGenerated:ne(n)}}const o=await Ce(e);return o||null}function O(e){return e.replace(/\s+/g," ").trim()}function R(e){return B(e).filter(t=>t.isWord).map(t=>t.lower||A(t.text)).filter(Boolean)}function Me(e,t){if(t<=0)return e;const n=B(e);let o=0,r=!1,a="";for(const g of n){if(!r){g.isWord&&(o+=1,o>t&&(r=!0,a+=g.text));continue}a+=g.text}return a.trimStart()}function Ne(e,t){const n=Math.min(e.length,t.length);for(let o=n;o>=1;o-=1){let r=!0;for(let a=0;a<o;a+=1)if(e[e.length-o+a]!==t[a]){r=!1;break}if(r)return o}return 0}function Ee(e,t){if(!t||t===e)return e;if(t.startsWith(e))return t;if(e.startsWith(t))return e;const n=R(e),o=R(t),r=Ne(n,o),a=Me(t,r);if(!a)return e;const g=/^[,.;:!?)]/.test(a)?"":" ";return`${e}${g}${a}`.replace(/\s+/g," ").trim()}function We(e,t){if(!e||!t)return!1;const n=O(e).toLowerCase(),o=O(t).toLowerCase();if(o.startsWith(n)&&o.length>n.length)return!0;const r=R(n),a=R(o);if(a.length<=r.length)return!1;let g=0;const h=Math.min(r.length,a.length);for(let b=0;b<h&&r[b]===a[b];b+=1)g+=1;return r.length<=2?g>=r.length:g>=r.length-1}function Ae(e){return/[.!?]["')\]]?$/.test(e.trim())}function Te(e){return R(e).length}function Ie(e,t){if(e.length===0)return[];const n=[...e].map(s=>({start:Math.max(0,s.start),end:Math.max(s.end,s.start+.3),text:O(s.text)})).filter(s=>s.text.length>0).sort((s,d)=>s.start-d.start||s.end-d.end);if(n.length===0)return[];const o=[];let r={...n[0]};const a=t.isAutoGenerated?.65:.45,g=t.isAutoGenerated?6.5:6,h=84,b=18;for(let s=1;s<n.length;s+=1){const d=n[s];if(We(r.text,d.text)){r.text=d.text,r.end=Math.max(r.end,d.end);continue}const v=d.start-r.end,w=Ee(r.text,d.text),k=Math.max(d.end,r.end)-r.start,L=v<=a&&k<=g&&w.length<=h&&Te(w)<=b,S=Ae(r.text);if(L&&(!S||t.isAutoGenerated)){r={start:r.start,end:Math.max(r.end,d.end),text:w};continue}o.push(r),r={...d}}o.push(r);const u=[];for(const s of o){const d=u[u.length-1];if(d&&d.text===s.text&&Math.abs(d.end-s.start)<.2){d.end=Math.max(d.end,s.end);continue}u.push(s)}return u}const Y="lingtext-native-caption-hide";function X(e){const t=document.getElementById(Y);if(!e){t==null||t.remove();return}if(t)return;const n=document.createElement("style");n.id=Y,n.textContent=`
    .ytp-caption-window-container {
      opacity: 0 !important;
      pointer-events: none !important;
    }
  `,document.head.appendChild(n)}function D(){return window.location.pathname!=="/watch"?null:new URLSearchParams(window.location.search).get("v")}function Re(e){let t=D();e(t);const n=()=>{const r=D();r!==t&&(t=r,e(r))},o=window.setInterval(n,300);return window.addEventListener("popstate",n),window.addEventListener("yt-navigate-finish",n),()=>{window.clearInterval(o),window.removeEventListener("popstate",n),window.removeEventListener("yt-navigate-finish",n)}}function Pe(e){let t=null,n=null,o=null;const r=new MutationObserver(h),a=new MutationObserver(h);function g(){const u=document.querySelector("#movie_player");u!==n&&(r.disconnect(),n=u,u&&r.observe(u,{childList:!0,subtree:!0}))}function h(){g(),t===null&&(t=requestAnimationFrame(()=>{t=null;const u=document.querySelector("#movie_player");if(!u){o=null,e(null);return}const s=u.getBoundingClientRect(),d={left:s.left,top:s.top,width:s.width,height:s.height};o&&d.left===o.left&&d.top===o.top&&d.width===o.width&&d.height===o.height||(o=d,e(s))}))}const b=document.body||document.documentElement;return b&&a.observe(b,{childList:!0,subtree:!0}),window.addEventListener("resize",h),window.addEventListener("scroll",h,!0),h(),()=>{r.disconnect(),a.disconnect(),window.removeEventListener("resize",h),window.removeEventListener("scroll",h,!0),t!==null&&cancelAnimationFrame(t)}}function ze(e,t){let n=0,o=e.length-1;for(;n<=o;){const r=n+o>>1,a=e[r];if(t<a.start){o=r-1;continue}if(t>=a.end){n=r+1;continue}return r}return-1}const _e=80,_={translator:ue.CHROME,apiKey:"",captionLanguage:"en",hideNativeCc:!0};function Be(){const e=document.querySelector(".ytp-subtitles-button");if(!e)return!1;const t=e.getAttribute("aria-pressed");return t==="true"?!0:t==="false"?!1:e.classList.contains("ytp-button-active")}function Fe({shadowRoot:e}){const t=f.useRef(null),n=f.useRef(null),[o,r]=f.useState(D()),[a,g]=f.useState(null),[h,b]=f.useState(_),[u,s]=f.useState(new Set),[d,v]=f.useState([]),[w,k]=f.useState([]),[L,S]=f.useState(!1),[W,G]=f.useState(!1),[j,M]=f.useState(""),[C,T]=f.useState(""),[re,I]=f.useState(!1),[F,N]=f.useState(null),[H,P]=f.useState(null);f.useEffect(()=>{const l=Re(c=>{r(c),M(""),T(""),k([]),S(!1),N(null),P(null)}),x=Pe(c=>{g(c)});return()=>{l(),x()}},[]),f.useEffect(()=>{(async()=>{try{const[c,m,p]=await Promise.all([chrome.runtime.sendMessage({type:"LT2_GET_WORDS"}),chrome.runtime.sendMessage({type:"LT2_GET_PHRASES"}),chrome.runtime.sendMessage({type:"LT2_GET_SETTINGS"})]);s(new Set(c.map(y=>y.wordLower))),v(m.map(y=>y.parts)),b({..._,...p,captionLanguage:"en"})}catch(c){console.error("[LingText] Failed to load extension data:",c)}})().catch(c=>{console.error("[LingText] Failed initial content load:",c)});const x=(c,m)=>{if(m==="local"){if(c.lt2_words){const p=c.lt2_words.newValue||[];s(new Set(p.map(y=>y.wordLower)))}if(c.lt2_phrases){const p=c.lt2_phrases.newValue||[];v(p.map(y=>y.parts))}if(c.lt2_settings){const p=c.lt2_settings.newValue||_;b({..._,...p,captionLanguage:"en"})}}};return chrome.storage.onChanged.addListener(x),()=>chrome.storage.onChanged.removeListener(x)},[]),f.useEffect(()=>{if(window.location.pathname!=="/watch"){G(!1);return}let l=null;const x=()=>{l===null&&(l=requestAnimationFrame(()=>{l=null,G(Be())}))},c=document.body||document.documentElement;if(!c){x();return}const m=new MutationObserver(x);m.observe(c,{attributes:!0,attributeFilter:["aria-pressed","class","style","hidden"],childList:!0,subtree:!0});const p=window.setInterval(x,500);return window.addEventListener("yt-navigate-finish",x),x(),()=>{m.disconnect(),window.clearInterval(p),window.removeEventListener("yt-navigate-finish",x),l!==null&&cancelAnimationFrame(l)}},[o]),f.useEffect(()=>{if(!o||window.location.pathname!=="/watch"){k([]),S(!1);return}let l=!1;return(async()=>{for(let c=0;c<3;c+=1){const m=await Se(o);if(l)return;if(m&&m.cues.length>0){const p=Ie(m.cues,{isAutoGenerated:m.isAutoGenerated});k(p),S(p.length>0);return}await new Promise(p=>setTimeout(p,900))}l||(k([]),S(!1))})().catch(c=>{console.error("[LingText] Failed to load transcript:",c),l||(k([]),S(!1))}),()=>{l=!0}},[o]),f.useEffect(()=>{if(!L||w.length===0||!W){M("");return}const l=document.querySelector("video");if(!l){M("");return}let x=0,c=-1;const m=()=>{const p=ze(w,l.currentTime);p!==-1&&p!==c&&(c=p,M(w[p].text)),p===-1&&(c!==-1&&(c=-1),M("")),x=requestAnimationFrame(m)};return m(),()=>{cancelAnimationFrame(x)}},[W,L,w]),f.useEffect(()=>{if(L||window.location.pathname!=="/watch")return;let l=null,x="";const c=()=>{l===null&&(l=requestAnimationFrame(()=>{if(l=null,!W){x="",M("");return}const y=document.querySelectorAll(".ytp-caption-window-container .ytp-caption-segment"),E=Array.from(y).map(z=>z.textContent||"").join(" ").replace(/\s+/g," ").trim();E!==x&&(x=E,M(E))}))},m=document.body||document.documentElement;if(!m)return;const p=new MutationObserver(c);return p.observe(m,{childList:!0,subtree:!0,characterData:!0}),c(),()=>{p.disconnect(),l!==null&&cancelAnimationFrame(l)}},[W,L,o]),f.useEffect(()=>{if(j===C)return;if(!j){T(""),I(!1);return}if(!C){T(j),I(!1);return}const l=C.trim().toLowerCase(),x=j.trim().toLowerCase();if(l.length>0&&x.startsWith(l)){T(j),I(!1);return}return n.current&&clearTimeout(n.current),I(!0),n.current=setTimeout(()=>{T(j),I(!1)},_e),()=>{n.current&&clearTimeout(n.current)}},[j,C]),f.useEffect(()=>{const l=h.hideNativeCc&&window.location.pathname==="/watch"&&W&&!!(j||C);return X(l),()=>{X(!1)}},[h.hideNativeCc,W,j,C]);const oe=f.useCallback(async(l,x,c,m)=>{try{const p=await chrome.runtime.sendMessage({type:"LT2_GET_WORD",payload:x});if(p){N({x:c,y:m,word:l,lower:x,translation:p.translation});return}const y=await q(l,h.translator,h.apiKey||void 0);N({x:c,y:m,word:l,lower:x,translation:y.translation||"..."})}catch(p){console.error("[LingText] Failed to open word popup:",p)}},[h]),U=f.useCallback(l=>{const x=new SpeechSynthesisUtterance(l);x.lang="en-US",speechSynthesis.speak(x)},[]),ie=f.useCallback(async l=>{await chrome.runtime.sendMessage({type:"LT2_DELETE_WORD",payload:l}),s(x=>{const c=new Set(x);return c.delete(l),c}),N(null)},[]),ae=f.useCallback(async(l,x,c)=>{const m={word:x,wordLower:l,translation:c,status:"unknown",addedAt:Date.now()};await chrome.runtime.sendMessage({type:"LT2_PUT_WORD",payload:m}),s(p=>{const y=new Set(p);return y.add(l),y}),N(null)},[]),$=f.useCallback(()=>{N(null),P(null)},[]),se=f.useCallback(async()=>{var z;const l=((z=e.getSelection)==null?void 0:z.call(e))||document.getSelection();if(!l||l.isCollapsed)return;let x;try{x=l.getRangeAt(0)}catch{return}if(!t.current)return;const m=l.toString().trim();if(!m||m.length<3||m.split(/\s+/).map(ce=>ce.trim()).filter(Boolean).length<2)return;const y=await q(m,h.translator,h.apiKey||void 0),E=x.getBoundingClientRect();P({x:E.left+E.width/2,y:E.top,text:m,translation:y.translation||"..."}),N(null),l.removeAllRanges()},[h.apiKey,h.translator,e]),le=f.useCallback(async(l,x)=>{const c=B(l).filter(p=>p.isWord).map(p=>p.lower||A(p.text)).filter(Boolean);if(c.length<2)return;const m={phrase:l,phraseLower:c.join(" "),translation:x,parts:c,addedAt:Date.now()};await chrome.runtime.sendMessage({type:"LT2_PUT_PHRASE",payload:m}),v(p=>[...p,c]),P(null)},[]);return window.location.pathname!=="/watch"||!a||!C?null:i.jsxs("div",{ref:t,className:"lingtext-wrapper",style:{position:"fixed",left:a.left,top:a.top,width:a.width,height:a.height,pointerEvents:"none",zIndex:2147483646},onMouseUp:se,children:[i.jsx("div",{className:`lingtext-container ${re?"lingtext-transitioning":""}`,children:i.jsx(he,{text:C,unknownSet:u,phrases:d,onWordClick:oe})}),F&&i.jsx(me,{popup:F,isUnknown:u.has(F.lower),onSpeak:U,onMarkKnown:ie,onMarkUnknown:ae,onClose:$}),H&&i.jsx(ge,{popup:H,onSpeak:U,onSave:le,onClose:$})]})}const Z="lingtext-root",Oe=`
.lingtext-wrapper {
  pointer-events: none;
}

.lingtext-container {
  position: absolute;
  bottom: 56px;
  left: 50%;
  transform: translateX(-50%);
  width: min(90%, 980px);
  text-align: center;
  pointer-events: auto;
  opacity: 1;
  transition: opacity 0.12s ease-in-out;
}

.lingtext-container.lingtext-transitioning {
  opacity: 0.78;
}

.lingtext-subtitle-overlay {
  display: inline;
  background: rgba(10, 10, 10, 0.86);
  color: #ffffff;
  padding: 10px 16px;
  border-radius: 6px;
  font-size: clamp(20px, 2.05vw, 30px);
  line-height: 1.35;
  font-family: "YouTube Noto", Roboto, Arial, sans-serif;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.75);
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}

.lingtext-word {
  cursor: pointer;
  border-radius: 2px;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.lingtext-word:hover {
  background: rgba(59, 130, 246, 0.42);
}

.lingtext-unknown {
  background: rgba(234, 179, 8, 0.26);
  border-bottom: 2px solid rgba(234, 179, 8, 0.7);
  font-weight: 600;
}

.lingtext-unknown:hover {
  background: rgba(234, 179, 8, 0.38);
}

.lingtext-phrase {
  text-decoration: underline;
  text-decoration-color: #4ade80;
  text-underline-offset: 4px;
}

.lingtext-reader-popup {
  --reader-surface-bg: rgba(255, 255, 255, 0.97);
  --reader-muted-bg: rgba(249, 250, 251, 0.97);
  --reader-text-color: #111827;
  --reader-muted-text-color: #6b7280;
  --reader-border-color: rgba(229, 231, 235, 0.95);
  --reader-accent-color: #0f9eda;
  position: fixed;
  z-index: 2147483647;
  background: var(--reader-surface-bg);
  color: var(--reader-text-color);
  border: 1px solid var(--reader-border-color);
  border-radius: 16px;
  box-shadow: 0 20px 42px rgba(15, 23, 42, 0.22);
  overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  font-size: 14px;
  pointer-events: auto;
  backdrop-filter: blur(12px);
}

.lingtext-reader-popup * {
  box-sizing: border-box;
}

.lingtext-reader-popup button {
  font-family: inherit;
}

.lingtext-reader-popup-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--reader-border-color);
  background: var(--reader-muted-bg);
}

.lingtext-reader-popup-title-group {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.lingtext-reader-popup-title-group.compact {
  gap: 10px;
}

.lingtext-reader-popup-icon {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: 12px;
  background: rgba(15, 158, 218, 0.12);
  color: var(--reader-accent-color);
}

.lingtext-reader-popup-icon.small {
  width: 32px;
  height: 32px;
}

.lingtext-reader-popup-icon svg,
.lingtext-reader-icon-button svg,
.lingtext-reader-action-button svg {
  width: 16px;
  height: 16px;
}

.lingtext-reader-popup-title {
  min-width: 0;
}

.lingtext-reader-popup-title h3 {
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.2;
}

.lingtext-reader-popup-title p {
  margin: 2px 0 0;
  color: var(--reader-muted-text-color);
  font-size: 11px;
  line-height: 1.2;
}

.lingtext-reader-selection-title {
  color: #1f2937;
  font-size: 14px;
  font-weight: 600;
}

.lingtext-reader-popup-header-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.lingtext-reader-icon-button {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: #6b7280;
  cursor: pointer;
  transition: background-color 0.2s ease, color 0.2s ease, opacity 0.2s ease;
}

.lingtext-reader-icon-button:hover {
  background: rgba(243, 244, 246, 0.9);
  color: #374151;
}

.lingtext-reader-icon-button:focus-visible,
.lingtext-reader-action-button:focus-visible {
  outline: 2px solid rgba(15, 158, 218, 0.55);
  outline-offset: 2px;
}

.lingtext-reader-section {
  padding: 12px 16px;
}

.lingtext-reader-section-compact {
  padding-bottom: 8px;
}

.lingtext-reader-section.no-bottom-padding {
  padding-bottom: 0;
}

.lingtext-reader-status-section {
  padding-top: 4px;
  padding-bottom: 8px;
}

.lingtext-reader-card {
  padding: 12px;
  border: 1px solid var(--reader-border-color);
  border-radius: 12px;
  background: var(--reader-muted-bg);
}

.lingtext-reader-card.accent {
  background: rgba(15, 158, 218, 0.05);
  border-color: rgba(15, 158, 218, 0.1);
}

.lingtext-reader-card.selected-text p {
  margin: 0;
  color: #374151;
  font-size: 14px;
  font-style: italic;
  line-height: 1.55;
}

.lingtext-reader-translation-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.lingtext-reader-category {
  margin: 0 0 2px;
  color: rgba(17, 24, 39, 0.5);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.04em;
  line-height: 1.2;
  text-transform: uppercase;
}

.lingtext-reader-category.accent {
  color: rgba(15, 158, 218, 0.7);
}

.lingtext-reader-translation-text {
  margin: 0;
  color: #1f2937;
  font-size: 14px;
  line-height: 1.4;
}

.lingtext-reader-main-translation {
  display: inline-block;
  color: #111827;
  font-size: 18px;
  font-weight: 700;
  line-height: 1.35;
}

.lingtext-reader-selection-translation {
  display: inline-block;
  color: #111827;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.4;
}

.lingtext-reader-status-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  line-height: 1;
}

.lingtext-reader-status-badge span {
  width: 6px;
  height: 6px;
  border-radius: 999px;
}

.lingtext-reader-status-badge.unknown {
  background: #fff7ed;
  color: #c2410c;
  border: 1px solid #fed7aa;
}

.lingtext-reader-status-badge.unknown span {
  background: #f97316;
}

.lingtext-reader-status-badge.known {
  background: #f0fdf4;
  color: #15803d;
  border: 1px solid #bbf7d0;
}

.lingtext-reader-status-badge.known span {
  background: #22c55e;
}

.lingtext-reader-actions {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 4px 16px 16px;
}

.lingtext-reader-actions.with-border {
  padding-top: 12px;
  border-top: 1px solid var(--reader-border-color);
  background: var(--reader-surface-bg);
}

.lingtext-reader-action-button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  min-height: 42px;
  padding: 10px 16px;
  border: 1px solid transparent;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.2;
  cursor: pointer;
  transition: background-color 0.2s ease, box-shadow 0.2s ease, opacity 0.2s ease;
}

.lingtext-reader-action-button:hover {
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.1);
}

.lingtext-reader-action-button.known {
  background: #f0fdf4;
  color: #15803d;
  border-color: #bbf7d0;
}

.lingtext-reader-action-button.known:hover {
  background: #dcfce7;
}

.lingtext-reader-action-button.unknown {
  background: #fff7ed;
  color: #c2410c;
  border-color: #fed7aa;
}

.lingtext-reader-action-button.unknown:hover {
  background: #ffedd5;
}

.lingtext-reader-action-button.secondary {
  background: var(--reader-muted-bg);
  color: #4b5563;
  border-color: var(--reader-border-color);
}

.lingtext-reader-action-button.secondary:hover {
  background: #f9fafb;
}
`;function Q(){if(document.getElementById(Z))return;const e=document.createElement("div");e.id=Z,document.body.appendChild(e);const t=e.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=Oe,t.appendChild(n);const o=document.createElement("div");t.appendChild(o),de.createRoot(o).render(i.jsx(Fe,{shadowRoot:t}))}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Q,{once:!0}):Q();
