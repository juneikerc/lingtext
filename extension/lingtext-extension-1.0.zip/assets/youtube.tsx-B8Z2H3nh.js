import{j as i,r as m,t as U,c as le}from"./translate-CVsMsjGM.js";import{T as ce}from"./translation-Dkakzs6h.js";function de(e){try{const t=JSON.parse(e);if(t&&typeof t=="object"&&t.word&&t.info)return t.info}catch{return null}return null}function ue({popup:e,onSpeak:t,onSave:n,onClose:o}){const r=window.innerWidth||1200,a=window.innerHeight||800,p=Math.min(400,Math.max(280,r-24)),g=340,b=Math.min(Math.max(12,e.x-p/2),r-p-12),d=e.y>a/2;let s;d?s=Math.max(12,e.y-g-12):s=Math.min(Math.max(12,e.y+12),Math.max(12,a-g-12));const l=de(e.translation),k=e.text.length>100?`${e.text.substring(0,100)}...`:e.text;return i.jsxs("div",{"data-reader-popup":"true",className:"lingtext-reader-popup lingtext-selection-popup",style:{left:b,top:s,width:p},onClick:h=>h.stopPropagation(),children:[i.jsxs("div",{className:"lingtext-reader-popup-header",children:[i.jsxs("div",{className:"lingtext-reader-popup-title-group compact",children:[i.jsx("div",{className:"lingtext-reader-popup-icon small","aria-hidden":"true",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("span",{className:"lingtext-reader-selection-title",children:"Texto seleccionado"})]}),i.jsxs("div",{className:"lingtext-reader-popup-header-actions",children:[i.jsx("button",{className:"lingtext-reader-icon-button",onClick:()=>t(e.text),title:"Escuchar","aria-label":"Escuchar",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M15.54 8.46a5 5 0 0 1 0 7.07",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("button",{className:"lingtext-reader-icon-button",onClick:o,title:"Cerrar","aria-label":"Cerrar",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("path",{d:"M18 6 6 18M6 6l12 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})})})]})]}),i.jsx("div",{className:"lingtext-reader-section no-bottom-padding",children:i.jsx("div",{className:"lingtext-reader-card selected-text",children:i.jsxs("p",{children:["“",k,"”"]})})}),i.jsx("div",{className:"lingtext-reader-section",children:i.jsx("div",{className:"lingtext-reader-card accent",children:l?i.jsx("div",{className:"lingtext-reader-translation-list",children:Object.entries(l).map(([h,v])=>i.jsxs("div",{children:[i.jsx("p",{className:"lingtext-reader-category accent",children:h}),i.jsx("p",{className:"lingtext-reader-translation-text",children:v.join(", ")})]},h))}):i.jsx("span",{className:"lingtext-reader-selection-translation",children:e.translation})})}),i.jsxs("div",{className:"lingtext-reader-actions with-border",children:[i.jsxs("button",{className:"lingtext-reader-action-button known",onClick:()=>n(e.text,e.translation),children:[i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("polyline",{points:"20 6 9 17 4 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})}),"Guardar frase"]}),i.jsxs("button",{className:"lingtext-reader-action-button secondary",onClick:()=>t(e.text),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Escuchar"]})]})]})}const pe=/[A-Za-z]+(?:'[A-Za-z]+)?/g;function W(e){return e.toLowerCase().normalize("NFKD").replace(/[^a-z']+/g,"")}function _(e){const t=[];let n=0,o;for(;o=pe.exec(e);){const[r]=o,a=o.index,p=a+r.length;a>n&&t.push({text:e.slice(n,a),isWord:!1,start:n,end:a}),t.push({text:r,isWord:!0,start:a,end:p,lower:W(r)}),n=p}return n<e.length&&t.push({text:e.slice(n),isWord:!1,start:n,end:e.length}),t}function xe({text:e,unknownSet:t,phrases:n,onWordClick:o}){const r=_(e),a=m.useMemo(()=>{const d=new Map;for(const s of n){if(s.length<2)continue;const l=s[0],k=d.get(l);k?k.push(s):d.set(l,[s])}return d},[n]);if(!e)return null;const p=new Array(r.length).fill(!1),g=(d,s)=>{const l=[];let k=0,h=d;for(;h<r.length&&k<s.length;){if(!r[h].isWord){h++;continue}if((r[h].lower||W(r[h].text))!==s[k])return null;l.push(h),k++,h++}return k===s.length?l:null};for(let d=0;d<r.length;d++){if(!r[d].isWord)continue;const s=r[d].lower||W(r[d].text),l=a.get(s);if(l)for(const k of l){const h=g(d,k);if(h)for(const v of h)p[v]=!0}}const b=(d,s,l)=>{const k=d.currentTarget.getBoundingClientRect();o(s,l,k.left+k.width/2,k.top)};return i.jsx("div",{className:"lingtext-subtitle-overlay",children:r.map((d,s)=>{if(!d.isWord)return i.jsx("span",{children:d.text},s);const l=d.lower||W(d.text),k=t.has(l),h=p[s];return i.jsx("span",{className:`lingtext-word ${k?"lingtext-unknown":""} ${h?"lingtext-phrase":""}`,onClick:v=>b(v,d.text,l),children:d.text},s)})})}function ge(e){try{const t=JSON.parse(e);if(t&&typeof t=="object"&&t.word&&t.info)return t.info}catch{return null}return null}function he({popup:e,isUnknown:t,onSpeak:n,onMarkKnown:o,onMarkUnknown:r,onClose:a}){const p=window.innerWidth||1200,g=window.innerHeight||800,b=Math.min(320,Math.max(260,p-24)),s=Math.max(12,g-320-12),l=Math.min(Math.max(12,e.x-b/2),p-b-12),k=Math.min(Math.max(12,e.y-80),s),h=ge(e.translation);return i.jsxs("div",{"data-reader-popup":"true",className:"lingtext-reader-popup lingtext-word-popup",style:{left:l,top:k,width:b},onClick:v=>v.stopPropagation(),children:[i.jsxs("div",{className:"lingtext-reader-popup-header",children:[i.jsxs("div",{className:"lingtext-reader-popup-title-group",children:[i.jsx("div",{className:"lingtext-reader-popup-icon","aria-hidden":"true",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M4 19.5A2.5 2.5 0 0 1 6.5 17H20",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsxs("div",{className:"lingtext-reader-popup-title",children:[i.jsx("h3",{children:e.word}),i.jsx("p",{children:"Palabra seleccionada"})]})]}),i.jsxs("div",{className:"lingtext-reader-popup-header-actions",children:[i.jsx("button",{className:"lingtext-reader-icon-button",onClick:()=>n(e.word),title:"Escuchar","aria-label":"Escuchar",children:i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M15.54 8.46a5 5 0 0 1 0 7.07",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]})}),i.jsx("button",{className:"lingtext-reader-icon-button",onClick:a,title:"Cerrar","aria-label":"Cerrar",children:i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("path",{d:"M18 6 6 18M6 6l12 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})})})]})]}),i.jsx("div",{className:"lingtext-reader-section lingtext-reader-section-compact",children:i.jsx("div",{className:"lingtext-reader-card",children:h?i.jsx("div",{className:"lingtext-reader-translation-list",children:Object.entries(h).map(([v,L])=>i.jsxs("div",{children:[i.jsx("p",{className:"lingtext-reader-category",children:v}),i.jsx("p",{className:"lingtext-reader-translation-text",children:L.join(", ")})]},v))}):i.jsx("span",{className:"lingtext-reader-main-translation",children:e.translation})})}),i.jsx("div",{className:"lingtext-reader-section lingtext-reader-status-section",children:i.jsxs("div",{className:`lingtext-reader-status-badge ${t?"unknown":"known"}`,children:[i.jsx("span",{}),t?"Por aprender":"Conocida"]})}),i.jsxs("div",{className:"lingtext-reader-actions",children:[t?i.jsxs("button",{className:"lingtext-reader-action-button known",onClick:()=>o(e.lower),children:[i.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:i.jsx("polyline",{points:"20 6 9 17 4 12",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})}),"Marcar como conocida"]}):i.jsxs("button",{className:"lingtext-reader-action-button unknown",onClick:()=>r(e.lower,e.word,e.translation),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("path",{d:"M12 20h9",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Marcar para repasar"]}),i.jsxs("button",{className:"lingtext-reader-action-button secondary",onClick:()=>n(e.word),children:[i.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",children:[i.jsx("polygon",{points:"11 5 6 9 2 9 2 15 6 15 11 19 11 5",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"}),i.jsx("path",{d:"M19.07 4.93a10 10 0 0 1 0 14.14",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round"})]}),"Escuchar de nuevo"]})]})]})}function fe(e){const t=document.createElement("textarea");return t.innerHTML=e,t.value}function Z(e){return fe(e).replace(/\s+/g," ").trim()}function me(e){const t=JSON.parse(e);if(!Array.isArray(t.events))return[];const n=[];for(const o of t.events){if(!Array.isArray(o.segs)||typeof o.tStartMs!="number")continue;const r=Z(o.segs.map(b=>b.utf8||"").join(""));if(!r)continue;const a=o.tStartMs/1e3,p=typeof o.dDurationMs=="number"&&o.dDurationMs>0?o.dDurationMs:2e3,g=a+p/1e3;n.push({start:a,end:g,text:r})}return n}function we(e){const o=new DOMParser().parseFromString(e,"text/xml").querySelectorAll("text"),r=[];return o.forEach(a=>{const p=Number.parseFloat(a.getAttribute("start")||""),g=Number.parseFloat(a.getAttribute("dur")||"");if(!Number.isFinite(p))return;const b=Z(a.textContent||"");if(!b)return;const d=Number.isFinite(g)&&g>0?g:2;r.push({start:p,end:p+d,text:b})}),r}function Q(e){const t=e.trim();if(!t)return[];let n=[];if(t.startsWith("{"))try{n=me(t)}catch{n=[]}if(n.length===0)try{n=we(t)}catch{n=[]}return n.sort((o,r)=>o.start-r.start||o.end-r.end),n}function be(e){const t=(e.languageCode||"").toLowerCase(),n=(e.vssId||"").toLowerCase();return t.startsWith("en")||n.includes(".en")}function ee(e){const t=(e.vssId||"").toLowerCase();return e.kind==="asr"||t.startsWith("a.")}function $(e){return e.replace(/\\u0026/g,"&")}function q(e,t){try{const n=new URL($(e));return n.searchParams.set("fmt",t),n.toString()}catch{const n=$(e);return n.includes("fmt=")?n.replace(/fmt=[^&]+/g,`fmt=${t}`):`${n}${n.includes("?")?"&":"?"}fmt=${t}`}}function K(e){var o,r;const t=e,n=(r=(o=t==null?void 0:t.captions)==null?void 0:o.playerCaptionsTracklistRenderer)==null?void 0:r.captionTracks;return Array.isArray(n)?n:[]}function ke(){var n,o,r;const e=K(window.ytInitialPlayerResponse);if(e.length>0)return e;const t=(r=(o=(n=window.ytplayer)==null?void 0:n.config)==null?void 0:o.args)==null?void 0:r.player_response;if(typeof t=="string"&&t)try{return K(JSON.parse(t))}catch{return[]}return[]}function ve(e){const t=e.filter(be);return t.length===0?null:t.find(o=>!ee(o))||t[0]||null}async function ye(e){const t=[q(e,"json3"),q(e,"srv3")];for(const n of t)try{const o=await fetch(n);if(!o.ok)continue;const r=await o.text(),a=Q(r);if(a.length>0)return a}catch(o){console.warn("[LingText] Caption track fetch failed:",o)}return[]}async function je(e){const t=[{fmt:"json3",isAutoGenerated:!1},{fmt:"json3",isAutoGenerated:!0},{fmt:"srv3",isAutoGenerated:!1},{fmt:"srv3",isAutoGenerated:!0}];for(const n of t)try{const o=new URL("https://www.youtube.com/api/timedtext");o.searchParams.set("v",e),o.searchParams.set("lang","en"),o.searchParams.set("fmt",n.fmt),n.isAutoGenerated&&o.searchParams.set("kind","asr");const r=await fetch(o);if(!r.ok)continue;const a=await r.text(),p=Q(a);if(p.length>0)return{cues:p,isAutoGenerated:n.isAutoGenerated}}catch(o){console.warn("[LingText] Direct caption API failed:",o)}return null}async function Le(e){const t=ke(),n=ve(t);if(n!=null&&n.baseUrl){const r=await ye(n.baseUrl);if(r.length>0)return{cues:r,isAutoGenerated:ee(n)}}const o=await je(e);return o||null}function O(e){return e.replace(/\s+/g," ").trim()}function T(e){return _(e).filter(t=>t.isWord).map(t=>t.lower||W(t.text)).filter(Boolean)}function Ce(e,t){if(t<=0)return e;const n=_(e);let o=0,r=!1,a="";for(const p of n){if(!r){p.isWord&&(o+=1,o>t&&(r=!0,a+=p.text));continue}a+=p.text}return a.trimStart()}function Se(e,t){const n=Math.min(e.length,t.length);for(let o=n;o>=1;o-=1){let r=!0;for(let a=0;a<o;a+=1)if(e[e.length-o+a]!==t[a]){r=!1;break}if(r)return o}return 0}function Me(e,t){if(!t||t===e)return e;if(t.startsWith(e))return t;if(e.startsWith(t))return e;const n=T(e),o=T(t),r=Se(n,o),a=Ce(t,r);if(!a)return e;const p=/^[,.;:!?)]/.test(a)?"":" ";return`${e}${p}${a}`.replace(/\s+/g," ").trim()}function Ne(e,t){if(!e||!t)return!1;const n=O(e).toLowerCase(),o=O(t).toLowerCase();if(o.startsWith(n)&&o.length>n.length)return!0;const r=T(n),a=T(o);if(a.length<=r.length)return!1;let p=0;const g=Math.min(r.length,a.length);for(let b=0;b<g&&r[b]===a[b];b+=1)p+=1;return r.length<=2?p>=r.length:p>=r.length-1}function We(e){return/[.!?]["')\]]?$/.test(e.trim())}function Ee(e){return T(e).length}function Ae(e,t){if(e.length===0)return[];const n=[...e].map(s=>({start:Math.max(0,s.start),end:Math.max(s.end,s.start+.3),text:O(s.text)})).filter(s=>s.text.length>0).sort((s,l)=>s.start-l.start||s.end-l.end);if(n.length===0)return[];const o=[];let r={...n[0]};const a=t.isAutoGenerated?.65:.45,p=t.isAutoGenerated?6.5:6,g=84,b=18;for(let s=1;s<n.length;s+=1){const l=n[s];if(Ne(r.text,l.text)){r.text=l.text,r.end=Math.max(r.end,l.end);continue}const k=l.start-r.end,h=Me(r.text,l.text),v=Math.max(l.end,r.end)-r.start,L=k<=a&&v<=p&&h.length<=g&&Ee(h)<=b,S=We(r.text);if(L&&(!S||t.isAutoGenerated)){r={start:r.start,end:Math.max(r.end,l.end),text:h};continue}o.push(r),r={...l}}o.push(r);const d=[];for(const s of o){const l=d[d.length-1];if(l&&l.text===s.text&&Math.abs(l.end-s.start)<.2){l.end=Math.max(l.end,s.end);continue}d.push(s)}return d}const V="lingtext-native-caption-hide";function J(e){const t=document.getElementById(V);if(!e){t==null||t.remove();return}if(t)return;const n=document.createElement("style");n.id=V,n.textContent=`
    .ytp-caption-window-container {
      opacity: 0 !important;
      pointer-events: none !important;
    }
  `,document.head.appendChild(n)}function D(){return window.location.pathname!=="/watch"?null:new URLSearchParams(window.location.search).get("v")}function Te(e){let t=D();e(t);const n=()=>{const r=D();r!==t&&(t=r,e(r))},o=window.setInterval(n,300);return window.addEventListener("popstate",n),window.addEventListener("yt-navigate-finish",n),()=>{window.clearInterval(o),window.removeEventListener("popstate",n),window.removeEventListener("yt-navigate-finish",n)}}function Ie(e){let t=null,n=null,o=null;const r=new MutationObserver(g),a=new MutationObserver(g);function p(){const d=document.querySelector("#movie_player");d!==n&&(r.disconnect(),n=d,d&&r.observe(d,{childList:!0,subtree:!0}))}function g(){p(),t===null&&(t=requestAnimationFrame(()=>{t=null;const d=document.querySelector("#movie_player");if(!d){o=null,e(null);return}const s=d.getBoundingClientRect(),l={left:s.left,top:s.top,width:s.width,height:s.height};o&&l.left===o.left&&l.top===o.top&&l.width===o.width&&l.height===o.height||(o=l,e(s))}))}const b=document.body||document.documentElement;return b&&a.observe(b,{childList:!0,subtree:!0}),window.addEventListener("resize",g),window.addEventListener("scroll",g,!0),g(),()=>{r.disconnect(),a.disconnect(),window.removeEventListener("resize",g),window.removeEventListener("scroll",g,!0),t!==null&&cancelAnimationFrame(t)}}function Re(e,t){let n=0,o=e.length-1;for(;n<=o;){const r=n+o>>1,a=e[r];if(t<a.start){o=r-1;continue}if(t>=a.end){n=r+1;continue}return r}return-1}const Pe=80,z={translator:ce.CHROME,apiKey:"",captionLanguage:"en",hideNativeCc:!0};function ze({shadowRoot:e}){const t=m.useRef(null),n=m.useRef(null),[o,r]=m.useState(D()),[a,p]=m.useState(null),[g,b]=m.useState(z),[d,s]=m.useState(new Set),[l,k]=m.useState([]),[h,v]=m.useState([]),[L,S]=m.useState(!1),[j,I]=m.useState(""),[C,E]=m.useState(""),[te,A]=m.useState(!1),[B,M]=m.useState(null),[F,R]=m.useState(null);m.useEffect(()=>{const u=Te(c=>{r(c),I(""),E(""),v([]),S(!1),M(null),R(null)}),f=Ie(c=>{p(c)});return()=>{u(),f()}},[]),m.useEffect(()=>{(async()=>{try{const[c,w,x]=await Promise.all([chrome.runtime.sendMessage({type:"LT2_GET_WORDS"}),chrome.runtime.sendMessage({type:"LT2_GET_PHRASES"}),chrome.runtime.sendMessage({type:"LT2_GET_SETTINGS"})]);s(new Set(c.map(y=>y.wordLower))),k(w.map(y=>y.parts)),b({...z,...x,captionLanguage:"en"})}catch(c){console.error("[LingText] Failed to load extension data:",c)}})().catch(c=>{console.error("[LingText] Failed initial content load:",c)});const f=(c,w)=>{if(w==="local"){if(c.lt2_words){const x=c.lt2_words.newValue||[];s(new Set(x.map(y=>y.wordLower)))}if(c.lt2_phrases){const x=c.lt2_phrases.newValue||[];k(x.map(y=>y.parts))}if(c.lt2_settings){const x=c.lt2_settings.newValue||z;b({...z,...x,captionLanguage:"en"})}}};return chrome.storage.onChanged.addListener(f),()=>chrome.storage.onChanged.removeListener(f)},[]),m.useEffect(()=>{if(!o||window.location.pathname!=="/watch"){v([]),S(!1);return}let u=!1;return(async()=>{for(let c=0;c<3;c+=1){const w=await Le(o);if(u)return;if(w&&w.cues.length>0){const x=Ae(w.cues,{isAutoGenerated:w.isAutoGenerated});v(x),S(x.length>0);return}await new Promise(x=>setTimeout(x,900))}u||(v([]),S(!1))})().catch(c=>{console.error("[LingText] Failed to load transcript:",c),u||(v([]),S(!1))}),()=>{u=!0}},[o]),m.useEffect(()=>{if(!L||h.length===0)return;const u=document.querySelector("video");if(!u)return;let f=0,c=-1;const w=()=>{const x=Re(h,u.currentTime);x!==-1&&x!==c?(c=x,I(h[x].text)):x===-1&&c!==-1&&(c=-1,I("")),f=requestAnimationFrame(w)};return w(),()=>{cancelAnimationFrame(f)}},[L,h]),m.useEffect(()=>{if(L||window.location.pathname!=="/watch")return;let u=null,f="";const c=()=>{u===null&&(u=requestAnimationFrame(()=>{u=null;const y=document.querySelectorAll(".ytp-caption-window-container .ytp-caption-segment"),N=Array.from(y).map(P=>P.textContent||"").join(" ").replace(/\s+/g," ").trim();N!==f&&(f=N,I(N))}))},w=document.body||document.documentElement;if(!w)return;const x=new MutationObserver(c);return x.observe(w,{childList:!0,subtree:!0,characterData:!0}),c(),()=>{x.disconnect(),u!==null&&cancelAnimationFrame(u)}},[L,o]),m.useEffect(()=>{if(j===C)return;if(!j){E(""),A(!1);return}if(!C){E(j),A(!1);return}const u=C.trim().toLowerCase(),f=j.trim().toLowerCase();if(u.length>0&&f.startsWith(u)){E(j),A(!1);return}return n.current&&clearTimeout(n.current),A(!0),n.current=setTimeout(()=>{E(j),A(!1)},Pe),()=>{n.current&&clearTimeout(n.current)}},[j,C]),m.useEffect(()=>{const u=g.hideNativeCc&&window.location.pathname==="/watch"&&!!(j||C);return J(u),()=>{J(!1)}},[g.hideNativeCc,j,C]);const ne=m.useCallback(async(u,f,c,w)=>{try{const x=await chrome.runtime.sendMessage({type:"LT2_GET_WORD",payload:f});if(x){M({x:c,y:w,word:u,lower:f,translation:x.translation});return}const y=await U(u,g.translator,g.apiKey||void 0);M({x:c,y:w,word:u,lower:f,translation:y.translation||"..."})}catch(x){console.error("[LingText] Failed to open word popup:",x)}},[g]),G=m.useCallback(u=>{const f=new SpeechSynthesisUtterance(u);f.lang="en-US",speechSynthesis.speak(f)},[]),re=m.useCallback(async u=>{await chrome.runtime.sendMessage({type:"LT2_DELETE_WORD",payload:u}),s(f=>{const c=new Set(f);return c.delete(u),c}),M(null)},[]),oe=m.useCallback(async(u,f,c)=>{const w={word:f,wordLower:u,translation:c,status:"unknown",addedAt:Date.now()};await chrome.runtime.sendMessage({type:"LT2_PUT_WORD",payload:w}),s(x=>{const y=new Set(x);return y.add(u),y}),M(null)},[]),H=m.useCallback(()=>{M(null),R(null)},[]),ie=m.useCallback(async()=>{var P;const u=((P=e.getSelection)==null?void 0:P.call(e))||document.getSelection();if(!u||u.isCollapsed)return;let f;try{f=u.getRangeAt(0)}catch{return}if(!t.current)return;const w=u.toString().trim();if(!w||w.length<3||w.split(/\s+/).map(se=>se.trim()).filter(Boolean).length<2)return;const y=await U(w,g.translator,g.apiKey||void 0),N=f.getBoundingClientRect();R({x:N.left+N.width/2,y:N.top,text:w,translation:y.translation||"..."}),M(null),u.removeAllRanges()},[g.apiKey,g.translator,e]),ae=m.useCallback(async(u,f)=>{const c=_(u).filter(x=>x.isWord).map(x=>x.lower||W(x.text)).filter(Boolean);if(c.length<2)return;const w={phrase:u,phraseLower:c.join(" "),translation:f,parts:c,addedAt:Date.now()};await chrome.runtime.sendMessage({type:"LT2_PUT_PHRASE",payload:w}),k(x=>[...x,c]),R(null)},[]);return window.location.pathname!=="/watch"||!a||!C?null:i.jsxs("div",{ref:t,className:"lingtext-wrapper",style:{position:"fixed",left:a.left,top:a.top,width:a.width,height:a.height,pointerEvents:"none",zIndex:2147483646},onMouseUp:ie,children:[i.jsx("div",{className:`lingtext-container ${te?"lingtext-transitioning":""}`,children:i.jsx(xe,{text:C,unknownSet:d,phrases:l,onWordClick:ne})}),B&&i.jsx(he,{popup:B,isUnknown:d.has(B.lower),onSpeak:G,onMarkKnown:re,onMarkUnknown:oe,onClose:H}),F&&i.jsx(ue,{popup:F,onSpeak:G,onSave:ae,onClose:H})]})}const Y="lingtext-root",_e=`
.lingtext-wrapper {
  pointer-events: none;
}

.lingtext-container {
  position: absolute;
  bottom: 56px;
  left: 50%;
  transform: translateX(-50%);
  width: min(90%, 980px);
  text-align: center;
  pointer-events: auto;
  opacity: 1;
  transition: opacity 0.12s ease-in-out;
}

.lingtext-container.lingtext-transitioning {
  opacity: 0.78;
}

.lingtext-subtitle-overlay {
  display: inline;
  background: rgba(10, 10, 10, 0.86);
  color: #ffffff;
  padding: 10px 16px;
  border-radius: 6px;
  font-size: clamp(20px, 2.05vw, 30px);
  line-height: 1.35;
  font-family: "YouTube Noto", Roboto, Arial, sans-serif;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.75);
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}

.lingtext-word {
  cursor: pointer;
  border-radius: 2px;
  transition: background-color 0.15s ease, color 0.15s ease;
}

.lingtext-word:hover {
  background: rgba(59, 130, 246, 0.42);
}

.lingtext-unknown {
  background: rgba(234, 179, 8, 0.26);
  border-bottom: 2px solid rgba(234, 179, 8, 0.7);
  font-weight: 600;
}

.lingtext-unknown:hover {
  background: rgba(234, 179, 8, 0.38);
}

.lingtext-phrase {
  text-decoration: underline;
  text-decoration-color: #4ade80;
  text-underline-offset: 4px;
}

.lingtext-reader-popup {
  --reader-surface-bg: rgba(255, 255, 255, 0.97);
  --reader-muted-bg: rgba(249, 250, 251, 0.97);
  --reader-text-color: #111827;
  --reader-muted-text-color: #6b7280;
  --reader-border-color: rgba(229, 231, 235, 0.95);
  --reader-accent-color: #0f9eda;
  position: fixed;
  z-index: 2147483647;
  background: var(--reader-surface-bg);
  color: var(--reader-text-color);
  border: 1px solid var(--reader-border-color);
  border-radius: 16px;
  box-shadow: 0 20px 42px rgba(15, 23, 42, 0.22);
  overflow: hidden;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  font-size: 14px;
  pointer-events: auto;
  backdrop-filter: blur(12px);
}

.lingtext-reader-popup * {
  box-sizing: border-box;
}

.lingtext-reader-popup button {
  font-family: inherit;
}

.lingtext-reader-popup-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 16px;
  border-bottom: 1px solid var(--reader-border-color);
  background: var(--reader-muted-bg);
}

.lingtext-reader-popup-title-group {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.lingtext-reader-popup-title-group.compact {
  gap: 10px;
}

.lingtext-reader-popup-icon {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  border-radius: 12px;
  background: rgba(15, 158, 218, 0.12);
  color: var(--reader-accent-color);
}

.lingtext-reader-popup-icon.small {
  width: 32px;
  height: 32px;
}

.lingtext-reader-popup-icon svg,
.lingtext-reader-icon-button svg,
.lingtext-reader-action-button svg {
  width: 16px;
  height: 16px;
}

.lingtext-reader-popup-title {
  min-width: 0;
}

.lingtext-reader-popup-title h3 {
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.2;
}

.lingtext-reader-popup-title p {
  margin: 2px 0 0;
  color: var(--reader-muted-text-color);
  font-size: 11px;
  line-height: 1.2;
}

.lingtext-reader-selection-title {
  color: #1f2937;
  font-size: 14px;
  font-weight: 600;
}

.lingtext-reader-popup-header-actions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.lingtext-reader-icon-button {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: #6b7280;
  cursor: pointer;
  transition: background-color 0.2s ease, color 0.2s ease, opacity 0.2s ease;
}

.lingtext-reader-icon-button:hover {
  background: rgba(243, 244, 246, 0.9);
  color: #374151;
}

.lingtext-reader-icon-button:focus-visible,
.lingtext-reader-action-button:focus-visible {
  outline: 2px solid rgba(15, 158, 218, 0.55);
  outline-offset: 2px;
}

.lingtext-reader-section {
  padding: 12px 16px;
}

.lingtext-reader-section-compact {
  padding-bottom: 8px;
}

.lingtext-reader-section.no-bottom-padding {
  padding-bottom: 0;
}

.lingtext-reader-status-section {
  padding-top: 4px;
  padding-bottom: 8px;
}

.lingtext-reader-card {
  padding: 12px;
  border: 1px solid var(--reader-border-color);
  border-radius: 12px;
  background: var(--reader-muted-bg);
}

.lingtext-reader-card.accent {
  background: rgba(15, 158, 218, 0.05);
  border-color: rgba(15, 158, 218, 0.1);
}

.lingtext-reader-card.selected-text p {
  margin: 0;
  color: #374151;
  font-size: 14px;
  font-style: italic;
  line-height: 1.55;
}

.lingtext-reader-translation-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.lingtext-reader-category {
  margin: 0 0 2px;
  color: rgba(17, 24, 39, 0.5);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.04em;
  line-height: 1.2;
  text-transform: uppercase;
}

.lingtext-reader-category.accent {
  color: rgba(15, 158, 218, 0.7);
}

.lingtext-reader-translation-text {
  margin: 0;
  color: #1f2937;
  font-size: 14px;
  line-height: 1.4;
}

.lingtext-reader-main-translation {
  display: inline-block;
  color: #111827;
  font-size: 18px;
  font-weight: 700;
  line-height: 1.35;
}

.lingtext-reader-selection-translation {
  display: inline-block;
  color: #111827;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.4;
}

.lingtext-reader-status-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  line-height: 1;
}

.lingtext-reader-status-badge span {
  width: 6px;
  height: 6px;
  border-radius: 999px;
}

.lingtext-reader-status-badge.unknown {
  background: #fff7ed;
  color: #c2410c;
  border: 1px solid #fed7aa;
}

.lingtext-reader-status-badge.unknown span {
  background: #f97316;
}

.lingtext-reader-status-badge.known {
  background: #f0fdf4;
  color: #15803d;
  border: 1px solid #bbf7d0;
}

.lingtext-reader-status-badge.known span {
  background: #22c55e;
}

.lingtext-reader-actions {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 4px 16px 16px;
}

.lingtext-reader-actions.with-border {
  padding-top: 12px;
  border-top: 1px solid var(--reader-border-color);
  background: var(--reader-surface-bg);
}

.lingtext-reader-action-button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  min-height: 42px;
  padding: 10px 16px;
  border: 1px solid transparent;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  line-height: 1.2;
  cursor: pointer;
  transition: background-color 0.2s ease, box-shadow 0.2s ease, opacity 0.2s ease;
}

.lingtext-reader-action-button:hover {
  box-shadow: 0 1px 3px rgba(15, 23, 42, 0.1);
}

.lingtext-reader-action-button.known {
  background: #f0fdf4;
  color: #15803d;
  border-color: #bbf7d0;
}

.lingtext-reader-action-button.known:hover {
  background: #dcfce7;
}

.lingtext-reader-action-button.unknown {
  background: #fff7ed;
  color: #c2410c;
  border-color: #fed7aa;
}

.lingtext-reader-action-button.unknown:hover {
  background: #ffedd5;
}

.lingtext-reader-action-button.secondary {
  background: var(--reader-muted-bg);
  color: #4b5563;
  border-color: var(--reader-border-color);
}

.lingtext-reader-action-button.secondary:hover {
  background: #f9fafb;
}
`;function X(){if(document.getElementById(Y))return;const e=document.createElement("div");e.id=Y,document.body.appendChild(e);const t=e.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=_e,t.appendChild(n);const o=document.createElement("div");t.appendChild(o),le.createRoot(o).render(i.jsx(ze,{shadowRoot:t}))}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",X,{once:!0}):X();
